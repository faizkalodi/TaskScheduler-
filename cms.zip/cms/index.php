<?php 
header('location:admin/');
?>
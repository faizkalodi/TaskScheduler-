<?php

if(empty($_SESSION['UID']))

{

	header("location:../admin/index.php?error_msg=invalid");

}

?>



<?php 

$ur  			= 	$_SERVER['REQUEST_URI'];

$ur1 			= 	explode('module/',$ur);

$ur2 			= 	explode('/',$ur1[1]);

$current_folder	=	$ur2[0];

$current_page	=	$ur2[1];

?>



             

             

  <!-- Left side column. contains the logo and sidebar -->

      <aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->

        <section class="sidebar">

          <!-- Sidebar user panel -->

          <div class="user-panel">

            <div  style="color:#FFFFFF; font-weight:bold; font-size:18px;background:#FFFFFF;padding:5px;"><a href="../dashboard/dashboard.php"><img src="<?php echo $App->adminlogo; ?>" /></a></div>

             <div align="left"></div>

          </div>

           <div align="left" style="color:#FFFFFF; background-color:#787878; height:30px; vertical-align:middle; padding-top:4px; padding-left:5px;" >MENU LINKS</div>

          <!-- /.search form -->

          <!-- sidebar menu: : style can be found in sidebar.less -->

           

          <ul class="sidebar-menu">

           

             <li <?php echo ($current_folder == 'dashboard')?' class="active" ':""; ?> ><a href="../dashboard/dashboard.php"><i class="fa fa-dashboard"></i> Dashboard <?php echo $current_url; ?></a></li>

<!--             <li><a href="../category/categories.php"><i class="fa fa-th"></i> Categories</a></li>
-->
             

            <!-- <li <?php //echo ($current_folder == 'page')?' class="active" ':"";?> > <a href="../page/pages.php"><i class="fa fa-globe"></i>Web Pages</a></li>-->

           <!--  <li <?php //echo ($current_folder == 'menu')?' class="active" ':"";?> ><a href="../menu/menu.php"><i class="fa fa-bars"></i> Menu</a></li>-->

             

        <!-- <div  class="header"align="left" style="color:#FFFFFF; background-color:#787878; height:30px; vertical-align:middle; padding-top:4px; padding-left:5px;" >MODULES</div>-->

         

           <li <?php echo ($current_folder == 'user')?' class="active" ':""; ?> ><a href="../employees/users.php"><i class="fa fa-group"></i>Employees</a></li>
           <li <?php echo ($current_folder == 'task')?' class="active" ':"";?> ><a href="../task/task.php"><i class="fa fa-tasks"></i>Tasks</a></li>
           
		   <?php if($_SESSION['UID'] <= 2){ ?>
              <li <?php echo ($current_folder == 'user')?' class="active" ':""; ?> ><a href="../user/users.php"><i class="fa fa-user-circle-o"></i>User Management</a></li>
			<?php } ?>
          

    <!-- </ul>

    </li>  -->      

             <li><a href="../siteinfo/settings.php"><i class="fa fa-cog"></i> Settings</a></li>

             

         </ul>  

          

           

          

          

        <!-- /.sidebar -->

      </aside>

     
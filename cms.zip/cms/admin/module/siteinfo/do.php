<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 10 April 2020
 *************************************************************************/
require_once('../../../config/application.php');

switch(strtolower((empty($_GET['op']) ? empty($_POST['op']) ? false : trim($_POST['op']) : trim($_GET['op'])))){
 
 	
	case 'new':
	/**
 	 * Add new 
 	 */
	$App->setup(true, 'user,siteinfo', false, 'webpage:new');
	$user = new user();
	$obj  = new siteinfo;
	#
	$obj->value['title'] 			= 	$_POST['title'];
	$obj->value['details'] 			= 	$_POST['details'];	
	$obj->value['upto'] 			= 	'2050-12-01';
	$obj->value['time'] 			= 	date('Y-m-d H:i:s');
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		if(empty($_POST['title']) or empty($_POST['details']) )
		{
			header("location:settings.php?op=new&&error_msg=empty");
		}
			
		else
		{
			#insert data
			if($obj->insert())
			{
				//header("location:phonebook.php?op=new&&error_msg=success");
				//header("location:phonebook.php");
				header("location:settings.php?op=add");
			}
			else
			{
				header("location:.settings.php?op=new&&error_msg=failed");
			}
		
		}
		
		
		
	}	
	
  	break;
	
	
	
	case 'edit':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user,siteinfo', false, 'webpage:new');
	$user = new user();
	$obj  = new siteinfo;
	#
	$id   = $_POST['id'];
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		if(empty($_POST['title']) or empty($_POST['details']))
		{
			header("location:settings.php?op=edit&id=$id&edit_error_msg=empty");
		}
			
		
		else
		{
			#update data
			$obj->key['id'] = $_POST['id'];
			if($obj->select())
			{					
				$obj->value['title'] 			= 	$_POST['title'];
				$obj->value['details'] 			= 	$_POST['details'];	
				$obj->value['upto'] 			= 	'2050-12-01';
				$obj->value['time'] 			= 	date('Y-m-d H:i:s');
			}
			if($obj->update())
			{
				header("location:settings.php?op=update");
			}
			else
			{
				header("location:settings.php?op=edit&&id=$id&edit_error_msg=failed");
			}
			
		}
		
	}	
	
  	break;
	
	
	case 'delete':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user,siteinfo', false, 'phone:new');
	$user = new user();
	$obj  = new siteinfo;
	#
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		#update data
		$obj->key['id'] = $_GET['id'];
		$obj->delete();
		header("location:settings.php?op=delete");
	}
  	break;
	
	

		
# 
}
exit;
?>

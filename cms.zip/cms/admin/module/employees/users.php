<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 10 April 2020
 *************************************************************************/
require_once('../../../config/application.php');
$App->setup(true,'user',true,'user:new');
$user 		= new user(true);
$obj  		= new user;
#
$module		= "Employees";#to display on title tag, if module empty as defau;t it wil; show as Admin Panel
#

if(empty($_SESSION['UID']))
{
	header("location:../../index.php?error_msg=auth");
}

$msg_op = "";
if($_GET['op'] == 'add')
{
	$msg_op = "User added successfully!";
}

if($_GET['op'] == 'update')
{
	$msg_op = "Specified record has been updated successfully!";
}

if($_GET['op'] == 'delete')
{
	$msg_op = "Specified record has been removed successfully!";
}

if($_GET['op'] == 'delete_about')
{
	$msg_op = "Sorry, this section cannot be deleted!";
}


#
?>
<!DOCTYPE html>
<html>
  <?php include("../../head.php"); ?>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
     <?php include("../../header.php"); ?>
    <?php include("../../sidebar.php");?>
      

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Employee Management</h1>
          <ol class="breadcrumb">
            <li><a href="../dashboard/dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="users.php">Users</a></li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
          
         <?php if($_GET['op'] == 'new'){ ?>
          <div class="col-xs-6"  style="margin-left:25%">
              
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Add New </h3>
                </div><!-- /.box-header -->
                <?php
                    #error display section
					$msg_success ="";
					$msg = "";
					if(!empty($_GET['error_msg']))
					{
					
						if($_GET['error_msg'] == 'empty')
						{
							$msg = "Please enter all required fields!";
						}
						
						
						
						if($_GET['error_msg'] == 'failed')
						{
							$msg = "Failed to add the phone number!";
						}
						
						if($_GET['error_msg'] == 'success')
						{
							$msg_success = "User added successfully!";
						}
						
						
					?>
					
                    <?php if(!empty($msg)){ ?><br><div align="center" style="color:#FF0000"><?php print $msg; ?></div><br><?php } ?>
                    <?php if(!empty($msg_success)){ ?><br><div align="center" style="color:#006633"><?php print $msg_success; ?></div><br><?php } ?>

                   <?php } ?>
                   
                     <!-- form start -->
                <form class="form-horizontal" action="do.php" method="post" enctype="multipart/form-data">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> First Name *</label>
                      <div class="col-sm-7">
                       <input type="hidden" name="op" id="op" value="new">
                       <input type="hidden" name="type" id="type" value="102">
                        <input type="name" class="form-control" id="fname"  name="fname" placeholder="First Name">
                      </div>
                    </div>
                    
                    
                    <div class="box-body">
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Last Name *</label>
                      <div class="col-sm-7">
                       <input type="hidden" name="op" id="op" value="new">
                        <input type="lname" class="form-control" id="lname"  name="lname" placeholder="Last Name">
                      </div>
                    </div>
                    
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Email *</label>
                      <div class="col-sm-7">
                           <input type="email" class="form-control" id="email"  name="email" placeholder="Email">
                      </div>
                    </div>
                    
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Username *</label>
                      <div class="col-sm-7">
                           <input type="uname" class="form-control" id="uname"  name="uname" placeholder="Username">
                      </div>
                    </div> 
                    
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Password *</label>
                      <div class="col-sm-7">
                           <input type="password" class="form-control" id="password"  name="password" placeholder="Password">
                      </div>
                    </div>
                    
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Designation *</label>
                      <div class="col-sm-7">
                           <input class="form-control" id="designation"  name="designation" placeholder="Designation">
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Department *</label>
                      <div class="col-sm-7">
                           <input class="form-control" id="department"  name="department" placeholder="Department">
                      </div>
                    </div>
                    
                   
                   
                  <!-- <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Image </label>
                      <div class="col-sm-7">
                          <input type="file" id="image" name="image">                 
                      </div>
                   </div>-->
                    
                                      
                  </div><!-- /.box-body -->
                  <div class="box-footer">
                    <button type="button" onClick="window.location='users.php'" class="btn btn-default">Close</button>
                    <button type="submit" class="btn btn-info pull-right">Save</button>
                  </div><!-- /.box-footer -->
                </form>

              
              </div>
              </div>
           </div>
           <?php } ?>
            
            
            <?php if($_GET['op'] == 'edit' & $_GET['id'] != '' ){ ?>
            <div class="col-xs-6"  style="margin-left:25%">
              
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Edit User</h3>
                </div><!-- /.box-header -->
                <?php
					#retrieve values
					$obj->key['id'] = $_GET['id'];
					$obj->select();
				
                    #error display section
					$msg_edit_success ="";
					$msg_edit = "";
					if(!empty($_GET['edit_error_msg']))
					{
					
						if($_GET['edit_error_msg'] == 'empty')
						{
							$msg_edit = "Please enter all required fields!";
						}
						
						
						
						
						
						if($_GET['edit_error_msg'] == 'failed')
						{
							$msg_edit = "Failed to add the user!";
						}
						
						if($_GET['edit_error_msg'] == 'success')
						{
							$msg_edit_success = "User updated successfully!";
						}
						
						
					?>
                <?php if(!empty($msg_edit)){ ?><br>
        <div align="center" style="color:#FF0000"><?php print $msg_edit; ?></div><br><?php } ?>
                    <?php if(!empty($msg_edit_success)){ ?><br><div align="center" style="color:#006633"><?php print $msg_edit_success; ?></div><br><?php } ?>

                   <?php } ?>

                <!-- form start -->
                <form class="form-horizontal" action="do.php" method="post" enctype="multipart/form-data">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label">First Name *</label>
                      <div class="col-sm-7">
                        <input type="hidden" name="op" id="op" value="edit">
                        <input type="hidden" name="id" id="id" value="<?php echo $obj->value['id']; ?>">
                        <input type="hidden" name="type" id="type" value="102">
                        <input type="hidden" name="cpanel" id="cpanel" value="2">
                        <input type="name" class="form-control" id="fname"  name="fname" placeholder="First Name" value="<?php echo $obj->value['fname']; ?>">
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label">Last Name *</label>
                      <div class="col-sm-7">
                        <input type="name" class="form-control" id="lname"  name="lname" placeholder="Last Name" value="<?php echo $obj->value['lname']; ?>">
                      </div>
                    </div>
                    
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Email *</label>
                      <div class="col-sm-7">
                        <input type="email" class="form-control" id="email"  name="email" placeholder="Email" value="<?php echo $obj->value['email']; ?>">
                      </div>
                    </div>
                    
                    
                     <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Username *</label>
                      <div class="col-sm-7">
                        <input type="text" class="form-control" id="uname"  name="uname" placeholder="Username" value="<?php echo $obj->value['uname']; ?>">
                      </div>
                    </div>
                    
                      <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Password *</label>
                      <div class="col-sm-7">
                        **********
                      </div>
                    </div>
                    
                  
                  
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Designation *</label>
                      <div class="col-sm-7">
                           <input class="form-control" id="designation"  name="designation" placeholder="Designation" value="<?php echo $obj->value['designation']; ?>">
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Department *</label>
                      <div class="col-sm-7">
                           <input class="form-control" id="department"  name="department" placeholder="Department" value="<?php echo $obj->value['department']; ?>">
                      </div>
                    </div>
                    
                  
                    
                <!--    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Image </label>
                      <div class="col-sm-7">
                      
                      		<?php //if (file_exists($App->data("users/{$obj->value['image']}", true))){ ?>
								<img src="<?php //echo $App->data("users/{$obj->value['image']}", false); ?>" alt="<?php //echo $obj->value['name'];?>" style="max-width:100px;">
							<?php //}	?>
                            
                          <input type="file" id="image" name="image">                 
                      </div>
                   </div>-->
                   
                   
                    
                  </div><!-- /.box-body -->
                  <div class="box-footer">
                    <button type="button" onClick="window.location='users.php'" class="btn btn-default">Close</button>
                    <button type="submit" class="btn btn-info pull-right">Save</button>
                  </div><!-- /.box-footer -->
                </form>
              </div>
            </div>
         <?php } ?>           
            
            
          
            <div class="col-xs-12">
              
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Employees</h3> 
                  <div align="right"><a href="../employees/users.php?op=new" title="Add new Contact">Add New+</a></div>
                  <?php if($msg_op != ""){ ?>
                  <div align="center">
                  	<span style="color:#006633"><?php echo $msg_op; ?></span> 
                  	<a href="users.php" title="Close Message">[X]</a> 
                  </div> 
				  
				  <?php } ?>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table width="101%" class="table table-bordered table-striped" id="example1">
                    <thead>
                      <tr>
                        <th width="10%">First Name</th>
                        <th width="12%"> Last Name</th>
                        <th width="12%">Username</th>
                        <th width="11%">Email</th>
                        <th width="13%">Department</th>
                        <th width="12%">Designation</th>
                        <th width="15%">Status</th>
                        <th width="15%">Options</th>
                      </tr>
                    </thead>
                    <tbody>
                    
                      
                      <?php
					  $obj->page['CONDITION'] 	.= "1";
					  
					  $suid = $_SESSION['UID'];
					 
					  if($_SESSION['UID'] == 2)
					  {
					  	 $obj->page['CONDITION'] 	.= " AND `id` >= '2' ";
					  }
					  
					  if($_SESSION['UID'] > 2)
					  {
					  	 $obj->page['CONDITION'] 	.= " AND `id` > '2' ";
					  }
					  
					  $obj->page['CONDITION'] 	.= " AND  `type` = '102' ";
					  $obj->page['ORDER'] 		= "`time` DESC";
					  $obj->startPaging(1000);
					  
					  ?>
                      
                      <?php
					   while($no = $obj->nextRecord()){ 
					  ?>
					  
                      <tr>
                        <td><?php echo ucfirst($obj->value['fname']); ?></td>
                        <td><?php echo ucfirst($obj->value['lname']); ?></td>
                        <td><?php echo ucfirst($obj->value['uname']); ?></td>
                        <td><?php echo ucfirst($obj->value['email']); ?></td>
                        <td><?php echo ucfirst($obj->value['department']); ?></td>
                        <td><?php echo ucfirst($obj->value['designation']); ?></td>
						<td>
							<?php 
							 if($obj->value['status'] == '2')
							 {
							 ?>
							 	<span style="color:#FF0000">Inactive</span>&nbsp;&nbsp;
                                <a href="do.php?op=activate&id=<?php echo $obj->value['id']; ?>" onClick="return confirm('Are you sure to activate this user?')">[ Activate ]</a>
                             <?php
							 }
							 if($obj->value['status'] == '1')
							 {
							 ?>
							 	<span style="color:#006600">Active</span>
                                <a href="do.php?op=deactivate&id=<?php echo $obj->value['id']; ?>" onClick="return confirm('Are you sure to deactivate this user?')">[ Deactivate ]</a>
                             <?php 
							 }
							?>                         </td>
                        <td>
                        
                        
                        <?php //if($_SESSION['UID']  == 1){ ?>
                       <?php  //if($obj->value['id'] >= 2){ ?> 
                        <a href="users.php?op=edit&id=<?php echo $obj->value['id']; ?>"><i class="fa fa-fw fa-edit"></i>View / Edit</a>
                        
                       
                        <a href="do.php?op=delete&id=<?php echo $obj->value['id']; ?>" onClick="return confirm('Are you sure to remove this user?');">&nbsp;
                       	 <?php if($obj->value['id'] > 2){ ?>  <i class="fa fa-fw fa-trash"></i>Delete <?php } ?></a>    
 
                         
                         
                         </td>
                      </tr>
                     <?php } ?>
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Department</th>
                        <th>Designation</th>
                        <th>Status</th>
                        <th>Options</th>
                      </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        <!-- /.content -->
      </div><!-- /.content-wrapper -->
      
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0.0
        </div>
        <strong>Developed @Bruce Clay</strong>
      </footer>
      
      
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
  <!-- ./wrapper -->

   <!-- jQuery 2.1.4 -->
    <script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.4 -->
    <script src="../../bootstrap/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../dist/js/demo.js"></script>
    <!-- page script -->
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
    
  	
    
         <!-- CK Editor -->
    <script src="https://cdn.ckeditor.com/4.4.3/standard/ckeditor.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="../../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <script>
      $(function () {
        // Replace the <textarea id="editor1"> with a CKEditor
        // instance, using default configuration.
        CKEDITOR.replace('details');
        //bootstrap WYSIHTML5 - text editor
        $(".textarea").wysihtml5();
      });
    </script>
   
    
  </body>
</html>

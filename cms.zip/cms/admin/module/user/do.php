<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 10 April 2020
 *************************************************************************/
require_once('../../../config/application.php');


switch(strtolower((empty($_GET['op']) ? empty($_POST['op']) ? false : trim($_POST['op']) : trim($_GET['op'])))){
 
 	
	case 'new':
	/**
 	 * Add new 
 	 */
	$App->setup(true, 'user,resize', true, 'User:new');
	$user 	= 	new user();
	$obj  	= 	new user;
	#
	$obj->value['type'] 			= 	$_POST['type'];
	$obj->value['fname'] 			= 	$_POST['fname'];
	$obj->value['lname'] 			= 	$_POST['lname'];
	$obj->value['email'] 			= 	$_POST['email'];
	$obj->value['uname'] 			= 	$_POST['uname'];
	$obj->value['password'] 		= 	$_POST['password'];
	$obj->value['status'] 			= 	2;
	$obj->value['cpanel'] 			= 	1;
	
	
	
	
	
	#image uploading section
	$act_fileExt 							= $obj->getExtension($_FILES['image']['name']);
	$act_fileName 							= 'user'.$obj->nextID().'.'.$act_fileExt;
    $activity_photo_path 					= $App->data("users", true);

			
	
     if(move_uploaded_file($_FILES['image']['tmp_name'],$activity_photo_path."/".$act_fileName))
	 {
		$resizeObj = new resize($activity_photo_path."/".$act_fileName);
		$resizeObj -> resizeImage(600, 338, 'crop');
		if($resizeObj -> saveImage($activity_photo_path."/".$act_fileName, 100))
		{
			$obj->value['image'] = $act_fileName;
		}
		else
		{
			//not uplaodede
		}
	 }
	#End image upload
	
	
	$obj->value['upto'] 			= 	'2080-12-01';
	
	
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		if(empty($_POST['fname']) or empty($_POST['uname']) or empty($_POST['password'])  or empty($_POST['email']) )
		{
			//die('empty');
			header("location:users.php?op=new&&error_msg=empty");
		}
			
		else
		{
			#insert data
			if($obj->insert())
			{
				header("location:users.php?op=add");
				
			}
			else
			{
				header("location:.users.php?op=new&&error_msg=failed");
			}
		
		}
		
		
		
	}	
	
  	break;
	
	
	
	case 'edit':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user,resize', true, 'Article:new');
	$user 	= 	new user();
	$obj  	= 	new user;
	#
	$id   = $_POST['id'];
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		if(empty($_POST['fname']) or empty($_POST['uname'])  or empty($_POST['email']))
		{  
		
			header("location:users.php?op=edit&id=$id&edit_error_msg=empty");
		}
			
		
		else
		{
			#update data
			$obj->key['id'] = $_POST['id'];
			if($obj->select())
			{					
				$obj->value['type'] 			= 	$_POST['type'];
				$obj->value['fname'] 			= 	$_POST['fname'];
				$obj->value['lname'] 			= 	$_POST['lname'];
				$obj->value['email'] 			= 	$_POST['email'];
				$obj->value['uname'] 			= 	$_POST['uname'];
				$obj->value['cpanel'] 			= 	2;//$_POST['cpanel'];
				
				#image uploading section
					
					if(!empty($_FILES['image']['name']))
					{
						$act_fileExt 							= $obj->getExtension($_FILES['image']['name']);
						$act_fileName 							= 'user'.$obj->value['id'].'.'.$act_fileExt;
						$activity_photo_path 					= $App->data("users", true);
					
					
					 	if(file_exists($activity_photo_path.'/'.$obj->value['image']))
						 {
							chmod($activity_photo_path.'/'.$obj->value['image'],0777);
							@unlink($activity_photo_path.'/'.$obj->value['image']);
						 }
						 
						 if(move_uploaded_file($_FILES['image']['tmp_name'],$activity_photo_path."/".$act_fileName))
						 {
							$resizeObj = new resize($activity_photo_path."/".$act_fileName);
							$resizeObj -> resizeImage(600, 338, 'crop');
							if($resizeObj -> saveImage($activity_photo_path."/".$act_fileName, 100))
							{
								$obj->value['image'] = $act_fileName;
							}
							else
							{
								//not uplaodede
							}
						
						}						
					}				
					
				#End image upload
				$obj->value['upto'] 			= 	'2080-12-01';
			}
			
			if($obj->update())
			{
				header("location:users.php?op=update");
			}
			else
			{
				header("location:users.php?op=edit&&id=$id&edit_error_msg=failed");
			}
			
		}
		
	}	
	
  	break;
	
	
	case 'delete':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user', true, 'user:new');
	$user = new user();
	$obj  = new user;
	#
	$activity_photo_path 					= $App->data("users", true);
	#
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		#Update data
		if($_GET['id'] <=2 )
		{
			echo "<script> alert('Sorry,You dont have rights to delete this main admin user!');return false;</script>";
		}
		else
		{
		
			$obj->key['id'] = $_GET['id'];
			if($obj->select())
			{
				if(file_exists($activity_photo_path.'/'.$obj->value['image']))
				 {
					chmod($activity_photo_path.'/'.$obj->value['image'],0777);
					@unlink($activity_photo_path.'/'.$obj->value['image']);
				 }
						 
				 $obj->delete();
				 header("location:users.php?op=delete");
			}
			
		
			
		}
		
	}
  	break;
	
	
	
	case 'activate':
	/**
 	 * Edit p
 	 */
	$App->setup(true, 'user', true, 'phone:new');
	$user = new user();
	$obj  = new user;
	#
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		#update data
		$obj->key['id'] = $_GET['id'];
		
		if($obj->select())
		{
			$obj->value['status'] = 1;
			if($obj->update())
			{
				header("location:users.php");
			}
		}	
	}
  	break;
	
	
	case 'deactivate':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user', true, 'phone:new');
	$user = new user();
	$obj  = new user;
	#
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		#update data
		$obj->key['id'] = $_GET['id'];
		
		if($obj->select())
		{
			$obj->value['status'] = 2;
			if($obj->update())
			{
				header("location:users.php");
			}
		}	
	}
  	break;
	
	
	case 'my_profile':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user,resize', true, 'Article:new');
	$user 	= 	new user();
	$obj  	= 	new user;
	#
	$id   = $_POST['id'];
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		if(empty($_POST['fname']) or empty($_POST['lname'])  or empty($_POST['uname'])  or empty($_POST['email']))
		{  
		
			header("location:myprofile.php?op=edit&id=$id&edit_error_msg=empty");
		}
			
		
		else
		{
			#update data
			$obj->key['id'] = $_POST['id'];
			if($obj->select())
			{		
				$obj->value['id'] 				= 	$_POST['id'];			
				$obj->value['fname'] 			= 	$_POST['fname'];
				$obj->value['lname'] 			= 	$_POST['lname'];
				$obj->value['uname'] 			= 	$_POST['uname'];
				$obj->value['email'] 			= 	$_POST['email'];
				
				$id = $obj->value['id'] ;
				
				#image uploading section
					//
					if(!empty($_FILES['image']['name']))
					{
						$act_fileExt 							= $obj->getExtension($_FILES['image']['name']);
						$act_fileName 							= 'user'.$obj->value['id'].'.'.$act_fileExt;
						$activity_photo_path 					= $App->data("users", true);
					
					
					 	if(file_exists($activity_photo_path.'/'.$obj->value['image']))
						 {
							chmod($activity_photo_path.'/'.$obj->value['image'],0777);
							@unlink($activity_photo_path.'/'.$obj->value['image']);
						 }
						 
						 if(move_uploaded_file($_FILES['image']['tmp_name'],$activity_photo_path."/".$act_fileName))
						 {
							$resizeObj = new resize($activity_photo_path."/".$act_fileName);
							$resizeObj -> resizeImage(600, 338, 'exact');
							if($resizeObj -> saveImage($activity_photo_path."/".$act_fileName, 100))
							{
								$obj->value['image'] = $act_fileName;
							}
							else
							{
								echo 'not uplaodede';
							}
						
						}						
					}				
					//	
				#End image upload
				//$obj->value['upto'] 			= 	'2080-12-01';
			}
			
			if($obj->update())
			{
				header("location:myprofile.php?op=edit&id=$id");
			}
			else
			{
				header("location:myprofile.php?op=edit&&id=$id&edit_error_msg=failed");
			}
			
		}
		
	}	
	
  	break;
	
	
	
	case 'changepass':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user', true, 'Article:new');
	$user 	= 	new user();
	$obj  	= 	new user;
	#
	$id   = $_POST['id'];
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		if(empty($_POST['cpass']) or empty($_POST['npass'])  or empty($_POST['cfnpass']))
		{  
		
			header("location:changepass.php?op=edit&id=$id&edit_error_msg=empty");
		}
		
		else if($_POST['npass'] != $_POST['cfnpass'])
		{
			header("location:changepass.php?op=edit&id=$id&edit_error_msg=match");
		}
		else
		{
			#update data
			if($user->changePassword2($_POST['cpass'], $_POST['npass'],$id))
			{
				header("location:changepass.php?op=edit&id=$id&edit_error_msg=success");
			}
			else
			{
				header("location:changepass.php?op=edit&id=$id&edit_error_msg=failed");
			}
			
		}
		
	}	
	
  	break;
	
	
	
	
	case 'signout':
		
		$App->setUp(false, "user", false, NONE);
		$user = new	user;
		$user->signOut();
 		header("location:../../index.php");
	break;	

# 
}
exit;
?>

<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 10 April 2020
 *************************************************************************/
require_once('../../../config/application.php');

switch(strtolower((empty($_GET['op']) ? empty($_POST['op']) ? false : trim($_POST['op']) : trim($_GET['op'])))){
 
 	
	case 'new':
	/**
 	 * Add new 
 	 */
	 
	$App->setup(true, 'user,files', true, 'files:new');
	$user 	= 	new user();
	$obj  	= 	new files;
	#
	$obj->value['id']						=	$obj->nextID();
	$obj->value['title'] 					= 	$_POST['title'];
	
	

	#image uploading section
	
	$act_fileExt 							= 	$obj->getExtension($_FILES['file']['name']);
	$a 										= 	preg_replace("/[^\p{L}\p{N}.-_]/u", "", $_FILES['file']['name']);
	$b 										= 	explode(".".$act_fileExt,$a);
	$act_fileName 							= 	$b[0].'.'.$act_fileExt;
    $activity_photo_path 					= 	$App->data("files", true);
	
	if($act_fileExt == "txt" or $act_fileExt == "doc" or $act_fileExt == "docx" or $act_fileExt == "xls" or $act_fileExt == "xlsx" or $act_fileExt == "pdf" or $act_fileExt == "jpg" or $act_fileExt == "jpeg" or $act_fileExt == "png" or $act_fileExt == "gif")
	{
	
	}
	else
	{
			header("location:files.php?op=new&&error_msg=file-error");die();
	}
	

	if($_FILES['file']['tmp_name']!="")
	{
		if(move_uploaded_file($_FILES['file']['tmp_name'],$activity_photo_path."/".$act_fileName))
		 {	
			$obj->value['file'] = $act_fileName;
		 }
		 else
		 {
			header("location:files.php?op=new&&error_msg=empty");
		 }
	}
	else
	{
		 header("location:files.php?op=new&&error_msg=empty");
	}   
	#End image upload
	
	
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
				
		if(empty($_POST['title']))
		{
			header("location:files.php?op=new&&error_msg=empty");
		}
			
		else
		{
			#insert data
			if($obj->insert())
			{
				header("location:files.php?op=add");
			}
			else
			{
				header("location:.files.php?op=new&&error_msg=failed");
			}
		
		}
		
	}	
	
  	break;
	
	
	
	case 'edit':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user,files', true, 'banner:new');
	$user 	= 	new user();
	$obj  	= 	new files;
	#
	$id   = $_POST['id'];
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		if(empty($_POST['title']))
		{
			header("location:files.php?op=edit&id=$id&edit_error_msg=empty");
		}
		else
		{
			
			#update data
			$obj->key['id'] = $_POST['id'];
			if($obj->select())
			{					
				$obj->value['title'] 			= 	$_POST['title'];
				
				
				#image uploading section
				
				$act_fileExt 	= $obj->getExtension($_FILES['file']['name']);
				if($act_fileExt == "txt" or $act_fileExt == "doc" or $act_fileExt == "docx" or $act_fileExt == "xls" or $act_fileExt == "xlsx" or $act_fileExt == "pdf" or $act_fileExt == "jpg" or $act_fileExt == "jpeg" or $act_fileExt == "png" or $act_fileExt == "gif")
				{
				
				}
				else
				{
						header("location:files.php?op=new&&error_msg=file-error");die();
				}
				
					if(!empty($_FILES['file']['name']))
					{
						$act_fileExt 							=   $obj->getExtension($_FILES['file']['name']);
						$a 										= 	preg_replace("/[^\p{L}\p{N}.-_]/u", "", $_FILES['file']['name']);
						$b 										= 	explode(".".$act_fileExt,$a);
						$act_fileName 							= 	$b[0].'.'.$act_fileExt;
						$activity_photo_path 					= 	$App->data("files", true);
						
					
					 	 if(file_exists($activity_photo_path.'/'.$obj->value['file']))
						 {
							chmod($activity_photo_path.'/'.$obj->value['image'],0777);
							@unlink($activity_photo_path.'/'.$obj->value['image']);
						 }
						 
						 if(move_uploaded_file($_FILES['file']['tmp_name'],$activity_photo_path."/".$act_fileName))
						 {
							$obj->value['file'] = $act_fileName;
						
						}						
					}				
					
				#End image upload
		
			}
			
			if($obj->update())
			{
				header("location:files.php?op=update");
			}
			else
			{
				header("location:files.php?op=edit&&id=$id&edit_error_msg=failed");
			}
			
		}
		
	}	
	
  	break;
	
	
	case 'delete':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user,files', true, 'banner:new');
	$user = new user();
	$obj  = new files;
	#
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	
	else
	{
		#remove image
		
		$activity_photo_path 					= $App->data("files", true);
		
		$obj->key['id'] = $_GET['id'];
		
		$obj->select();
		 if (file_exists($App->data("files/{$obj->value['file']}", true)))
		 {
			chmod($activity_photo_path.'/'.$obj->value['file'],0777);
			@unlink($activity_photo_path.'/'.$obj->value['file']);

		 }
	
		#update data
		
		$obj->delete();
		header("location:files.php?op=delete");
	}
  	break;
	
	
# 
}
exit;
?>

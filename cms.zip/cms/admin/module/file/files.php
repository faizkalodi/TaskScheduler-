<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 10 April 2020
 *************************************************************************/
require_once('../../../config/application.php');
$App->setup(true,'user,files',true,'files:new');
$user 		= 	new user(true);
$obj  		= 	new files;
#
if(empty($_SESSION['UID']))
{
	header("location:../../index.php?error_msg=auth");
}

$msg_op = "";
if($_GET['op'] == 'add')
{
	$msg_op = "New record has been added successfully!";
}

if($_GET['op'] == 'update')
{
	$msg_op = "Specified record has been updated successfully!";
}

if($_GET['op'] == 'delete')
{
	$msg_op = "Specified record has been removed successfully!";
}

if($_GET['op'] == 'delete_about')
{
	$msg_op = "Sorry, this section cannot be deleted!";
}

if($_GET['op'] == 'default_article')
{
	$msg_op = "The record has been changed to default!";
}

#
?>
<!DOCTYPE html>
<html>
  <?php include("../../head.php"); ?>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
     <?php include("../../header.php"); ?>
    <?php include("../../sidebar.php");?>
      

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            File Manager</h1>
          <ol class="breadcrumb">
            <li><a href="../dashboard/dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="files.php">File Manager</a></li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
          
         <?php if($_GET['op'] == 'new'){ ?>
          <div class="col-xs-6"  style="margin-left:25%">
              
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Add New </h3>
                </div><!-- /.box-header -->
                <?php
                    #error display section
					$msg_success ="";
					$msg = "";
					if(!empty($_GET['error_msg']))
					{
					
						if($_GET['error_msg'] == 'empty')
						{
							$msg = "Please enter all required fields!";
						}
						
						
						
						if($_GET['error_msg'] == 'failed')
						{
							$msg = "Failed to add!";
						}
						
						if($_GET['error_msg'] == 'file-error')
						{
							$msg = "The file type is not supported!";
						}
						
						if($_GET['error_msg'] == 'success')
						{
							$msg_success = " added successfully!";
						}
						
						
					?>
					
                    <?php if(!empty($msg)){ ?><br><div align="center" style="color:#FF0000"><?php print $msg; ?></div><br><?php } ?>
                    <?php if(!empty($msg_success)){ ?><br><div align="center" style="color:#006633"><?php print $msg_success; ?></div><br><?php } ?>

                   <?php } ?>

                <!-- form start -->
                <form class="form-horizontal" action="do.php" method="post" enctype="multipart/form-data">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-2 control-label"> Title *</label>
                      <div class="col-sm-8">
                       <input type="hidden" name="op" id="op" value="new">
						<input type="text" name="title" id="title" class="form-control" required>                       
                      </div>
                    </div>
                    
               
                    
                 <!--  <div class="form-group">
                      <label for="inputEmail3" class="col-sm-2 control-label"> Type *</label>
                      <div class="col-sm-8">
                          <select name="type" id="type"  class="form-control" required >
                            <option value="en">English</option>
                            <option value="ar">Arabic</option>
                          </select>
                      </div>
                   </div>-->
                    
                   

                  <div class="form-group">
                      <label for="inputEmail3" class="col-sm-2 control-label"> 
                      File *<br>
                      </label>
                        <div class="col-sm-8">
                            <input type="file" id="file" name="file"  required>
                        </div>                            
                   </div>
                  
                  </div><!-- /.box-body -->
                  <div class="box-footer">
                    <button type="button" onClick="window.location='files.php'" class="btn btn-default">Close</button>
                    <button type="submit" class="btn btn-info pull-right">Save</button>
                  </div><!-- /.box-footer -->
                </form>
              </div>
              </div>
           <?php } ?>
            
            
            <?php if($_GET['op'] == 'edit' & $_GET['id'] != '' ){ ?>
            <div class="col-xs-6"  style="margin-left:25%">
              
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Edit </h3>
                </div><!-- /.box-header -->
                <?php
					#retrieve values
					$obj->key['id'] = $_GET['id'];
					$obj->select();
				
                    #error display section
					$msg_edit_success ="";
					$msg_edit = "";
					if(!empty($_GET['edit_error_msg']))
					{
					
						if($_GET['edit_error_msg'] == 'empty')
						{
							$msg_edit = "Please enter all required fields!";
						}
						
						if($_GET['edit_error_msg'] == 'failed')
						{
							$msg_edit = "Failed to add the page!";
						}
						
						if($_GET['edit_error_msg'] == 'success')
						{
							$msg_edit_success = "Updated successfully!";
						}
						
						
					?>
               		 <?php if(!empty($msg_edit)){ ?><br>
       						 <div align="center" style="color:#FF0000"><?php print $msg_edit; ?></div><br><?php } ?>
                    <?php if(!empty($msg_edit_success)){ ?><br><div align="center" style="color:#006633"><?php print $msg_edit_success; ?></div><br><?php } ?>

                   <?php } ?>

                <!-- form start -->
                <form class="form-horizontal" action="do.php" method="post" enctype="multipart/form-data">
                  
                  <div class="box-body">
                     
                     <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Title *</label>
                      <div class="col-sm-7">
                        <input type="hidden" name="op" id="op" value="edit">
                        <input type="hidden" name="id" id="id" value="<?php echo $obj->value['id']; ?>">
                        <input type="text" name="title" id="title" class="form-control"  value="<?php echo $obj->value['title']; ?>" required >
                      </div>
                    </div>
                    
                  
                   
                   
                 
                   
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> File *</label>
                     <br>
                  		<div class="col-sm-7">
                      		
                            <?php echo $obj->value['file']; ?>
                          <input type="file" id="file" name="file">
                  		</div>
                   </div>
                   
                   
                    
                  </div><!-- /.box-body -->
                  <div class="box-footer">
                    <button type="button" onClick="window.location='files.php'" class="btn btn-default">Close</button>
                    <button type="submit" class="btn btn-info pull-right">Save</button>
                  </div><!-- /.box-footer -->
                </form>
              </div>
            </div>
         <?php } ?>           
            
            
          
            <div class="col-xs-12">
              
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Files</h3> 
                  <div align="right">
                 	 <a href="../file/files.php?op=new" title="Add new Contact">Add New+</a>
                  </div>
                  <?php if($msg_op != ""){ ?>
                      <div align="center">
                        <span style="color:#006633"><?php echo $msg_op; ?></span> 
                        <a href="files.php" title="Close Message">[X]</a> 
                      </div> 
				  <?php } ?>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table width="101%" class="table table-bordered table-striped" id="example1">
                    <thead>
                      <tr>
                        <th width="7%">File Type</th>
                        <th width="17%">Title</th>
                        <th width="38%"> File Path</th>
                        <th width="16%">Date</th>
                        <th width="22%">Options</th>
                      </tr>
                    </thead>
                    <tbody>
                      
                      <?php
					  $obj->page['CONDITION'] 	= "1";
					  $obj->page['ORDER'] 		= " `time` DESC";
					  $obj->startPaging(1000);
					  ?>
                      
                      
                      <?php
					   while($no = $obj->nextRecord()){ 
					  ?>
					  
                      <tr>
                        <td>
					    <?php echo  $ext =  $obj->getExtension($obj->value['file']); ?>
                         </td>
                        <td><?php echo ucfirst($obj->value['title']); ?></td>
                        <td> <a href='<?php echo $App->name.'config/data/files/'.$obj->value['file']; ?>' target="_blank"><?php echo $App->name.'config/data/files/'.$obj->value['file']; ?></a></td>
                        <td><?php echo date('d F Y,  h:i:s A',strtotime($obj->value['time'])); ?></td>
                        <td>
                        <a href="files.php?op=edit&id=<?php echo $obj->value['id']; ?>"><i class="fa fa-fw fa-edit"></i>View / Edit</a>
                        
                        <a href="do.php?op=delete&id=<?php echo $obj->value['id']; ?>" onClick="return confirm('Are you sure to remove this image?');">&nbsp;
                        <i class="fa fa-fw fa-trash"></i>Delete</a>                         </td>
                      </tr>
                     <?php } ?>
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>File</th>
                        <th>Title</th>
                        <th>File Path</th>
                        <th>Date</th>
                        <th>Options</th>
                      </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0.0
        </div>
        <strong>Developed @Bruce Clay</strong>
      </footer>
      
      
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
  </div><!-- ./wrapper -->

   <!-- jQuery 2.1.4 -->
    <script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.4 -->
    <script src="../../bootstrap/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../dist/js/demo.js"></script>
    <!-- page script -->
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
    
  	
    
         <!-- CK Editor -->
    <script src="https://cdn.ckeditor.com/4.4.3/standard/ckeditor.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="../../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <script>
      $(function () {
        // Replace the <textarea id="editor1"> with a CKEditor
        // instance, using default configuration.
        CKEDITOR.replace('details');
        //bootstrap WYSIHTML5 - text editor
        $(".textarea").wysihtml5();
      });
    </script>
   
    
  </body>
</html>

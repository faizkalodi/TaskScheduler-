<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 10 April 2020
 ***********************************************************************/
class menu extends tableObject{

	var $breadcums  	= array();
	var $printBreadcums = false;

	function menu()
	{
		$this->reset('menu', 'id', 'type,parent,title_en,title_ar,url_name_en,url_name_ar,url,order,time');
	}
	
	function getMenus()
	{
			$html 	= "";
			$query  =  "SELECT * FROM `$this->table` "; 
			$res    =   mysql_query($query) or die(mysql_error());
			
			$html .= '<option value="0" selected >Root</option>';
			while($row_pgs = mysql_fetch_array($res))
			{
				$html .= '<option value="'.$row_pgs['id'].'">'.$row_pgs['title_en'].'</option>';
			}
														
		return ($html);
	}
	
	function getMenus_edit($parent)
	{
		$id = $this->value['id'];
		$html 	= "";
		$query  =  "SELECT * FROM `$this->table` WHERE `id` <> '{$id}'  ";
		$res    =   mysql_query($query) or die(mysql_error());
		
		
			$html .= '<option value="0" selected >Root</option>';
			while($row_pgs = mysql_fetch_array($res))
			{
				if($parent == $row_pgs['id'])
				{
					$html .= '<option value="'.$row_pgs['id'].'" selected >'.$row_pgs['title_en'].'</option>';
				}
				else
				{
					$html .= '<option value="'.$row_pgs['id'].'">'.$row_pgs['title_en'].'</option>';
				}
				
			}
														
		return ($html);
	}
	
	
	function getMenuName($id,$language)
	{
		
		if($id == 0)
		{
			$title = 'Root';
		}
		else
		{
				$query  =  "SELECT * FROM `$this->table` WHERE `id` = '{$id}' LIMIT 1  ";//die($query);
				$res    =   mysql_query($query) or die(mysql_error());
				
				while($row = mysql_fetch_array($res))
				{
					if($language == 'en')
					{
						$title = $row['title_en'];
					}
					if($language == 'ar')
					{
						$title = $row['title_ar'];
					}
					
			  }
		}
	  return $title;
	}
	
	function getMenuTitleArabic($title_en)
	{
		$query  =  "SELECT * FROM `$this->table` WHERE `title_en` = '{$title_en}' ORDER by `order` ASC "; 
		$res    =   mysql_query($query) or die(mysql_error());
		while($row = mysql_fetch_array($res))
		{
			$title_ar = $row['title_ar'];
		}
		return($title_ar);
	}
	
	function getMenuTitleEnglish($title_ar)
	{
		$query  =  "SELECT * FROM `$this->table` WHERE `title_ar` = '{$title_ar}' ORDER by `order` ASC "; 
		$res    =   mysql_query($query) or die(mysql_error());
		while($row = mysql_fetch_array($res))
		{
			$title_ar = $row['title_en'];
		}
		return($title_en);
	}
	
	
	#
	function getHeaderMenu($type)
	{
		$query  =  "SELECT * FROM `$this->table` WHERE `type` = '{$type}' ORDER by `order` ASC "; 
		$res    =   mysql_query($query) or die(mysql_error());
		return($res);
	}
	
	function getHeaderMenuRoot($type,$limit_start,$limit_end)
	{
		$query  =  "SELECT * FROM `$this->table` WHERE `type` = '{$type}' AND `parent` = '0' ORDER by `order` ASC LIMIT $limit_start, $limit_end "; //die($query);
		$res    =   mysql_query($query) or die(mysql_error());
		return($res);
	}
	
	function getHeaderMenuRootLimit($type)
	{
		$query  =  "SELECT * FROM `$this->table` WHERE `type` = '{$type}' AND `parent` = '0' "; //die($query);
		$res    =   mysql_query($query) or die(mysql_error());
		$nr 	= 	mysql_num_rows($res);
		return($nr);
	}
	
	function getHeaderMenuRootLimitEdit($type,$id)
	{
		$query  =  "SELECT * FROM `$this->table` WHERE `type` = '{$type}' AND `parent` = '0' AND `id` <> '{$id}' "; //die($query);
		$res    =   mysql_query($query) or die(mysql_error());
		$nr 	= 	mysql_num_rows($res);
		return($nr);
	}
	
	
	function getSubmenus($parent)
	{
		$query  =  "SELECT * FROM `$this->table` WHERE `parent` = '{$parent}' ORDER by `order` ASC "; //die($query);
		$res    =   mysql_query($query) or die(mysql_error());
		return($res);
	}
	
	function getMenuActive($menu_name)
	{
		$query  =  "SELECT * FROM `$this->table` WHERE `url_name_en` = '{$menu_name}' LIMIT 1 "; //die($query);
		$res    =   mysql_query($query) or die(mysql_error());
		$row    =   mysql_fetch_assoc($res);
		
		if($row['parent'] == 0)
		{
			$val =$row['url_name_en'];
		}
		else
		{
			$this->key['id'] = $row['parent'];
			$this->select();
			$menu_n = $this->value['url_name_en'];
			$val = $this->getMenuActive($menu_n);
		}
		return($val);
	}
	
	
	
	function getMenuUrl($menu_url_name)
	{
		$query  =  "SELECT * FROM `$this->table` WHERE `url_name_en` = '{$menu_url_name}' LIMIT 1 "; //die($query);
		$res    =   mysql_query($query) or die(mysql_error());
		$row    =   mysql_fetch_assoc($res);
		
		if(mysql_num_rows($res) > 0)
		{
			return $row['url'];
		}
	}
	
	
	
	#Add to Ht access
	function  addToHtaccess($myfile,$replace_str,$url_name)
	{
		$reading 	  = 	fopen($myfile, 'r');
		$writing 	  = 	fopen('myfile.tmp', 'w');
		$replaced 	  = 	false;
		
		$f = fopen($myfile, "a+");
		$content = $replace_str;# line adding bootm of ht access
		fwrite($f, $content);
		
		if($replaced) 
		{
		  
		  $old_file_location ="../../../config/htaccess_backups/";
		  $old_file = $old_file_location.'Backup-htaccess-'.date('Y-m-d h-i-s').'.txt';
		  
		  rename($myfile, $old_file);
		  rename('myfile.tmp', $myfile);
		} else {
		  @unlink('myfile.tmp');
		}
		return;
	
	}
	
	# Htacees updating
	function updateHtaccess($myfile,$replace_str,$url_name,$url_name_current = false)
	{
		$myfile 	  = 	$myfile;
		$reading 	  = 	fopen($myfile, 'r');
		$writing 	  = 	fopen('myfile.tmp', 'w');
		$replaced 	  = 	false;
		$replace_str  = 	$replace_str;
				
		while (!feof($reading)) 
		{
			 $line = fgets($reading);
			 $line_splt   = explode('^',$line);
			 $line_part2 = explode('$',$line_splt[1]);
			 $ht_str_to_compare = $line_part2[0];
			
			 if ($url_name_current == $ht_str_to_compare) 
			 {
				$line = $replace_str;#line replace text
				$replaced = true;
			 }
			fputs($writing, $line);
		}#End while
		fclose($reading); fclose($writing);
		
		#call add
		if($replaced == false)
		{
			$this->addToHtaccess($myfile,$replace_str,$url_name);
		}
		
		#might as well not overwrite the file if we didn't replace anything
		if ($replaced) 
		{
		  $old_file_location ="../../../config/htaccess_backups/";
		  $old_file = $old_file_location.'Backup-htaccess-'.date('Y-m-d h-i-s').'.txt';
		  rename($myfile, $old_file);
		  rename('myfile.tmp', $myfile);
		} 
		else 
		{
		  @unlink('myfile.tmp');
		}
		return;
	}
	
	# Htacees remove line
	function removeHtaccessline($myfile,$replace_str,$url_name)
	{
		$reading = fopen($myfile, 'r');
		$writing = fopen('myfile.tmp', 'w');
		
		$replaced = false;
		$replace_str  = "";
		
		while (!feof($reading)) 
		{
			 $line = fgets($reading);
			 $line_splt   = explode('^',$line);
			 $line_part2 = explode('$',$line_splt[1]);
			 $ht_str_to_compare = $line_part2[0];
			
			 if ($url_name == $ht_str_to_compare) 
			 {
				unset($line);
				$line = $replace_str;#line replace text
				$replaced = true;
			 }
			fputs($writing, $line);
		}#End while
			
		fclose($reading); fclose($writing);
		# might as well not overwrite the file if we didn't replace anything
		if ($replaced) 
		{
		  $old_file_location ="../../../config/htaccess_backups/";
		  $old_file = $old_file_location.'Backup-htaccess-'.date('Y-m-d h-i-s').'.txt';
		  
		  rename($myfile, $old_file);
		  rename('myfile.tmp', $myfile);
		} else {
		  @unlink('myfile.tmp');
		}
		return;
	}
		
	function getMenuID($page_id)
	{
		$url    =  'page.php?page_id='.$page_id;
		$query  =  "SELECT `id` FROM `$this->table` WHERE `url` = '{$url}' LIMIT 1  ";//die($query);
		$res    =   mysql_query($query) or die(mysql_error());
		$row    =   mysql_fetch_assoc($res);
		return $row['id'];
	}
	
	function getBreadCrumbs($id,$language)
	{
		
		$query     =  "SELECT * FROM `$this->table` WHERE `id` = '{$id}' LIMIT 1  ";
		$res       =   mysql_query($query) or die(mysql_error());
		$row       =   mysql_fetch_assoc($res);
		
		if($language == 'en')
		{
			$this->breadcums[] = $row['title_en'];
		}
		
		if($language == 'ar')
		{
			$this->breadcums[] = $row['title_ar'];
		}
		
		
		
		if($row['parent'] != 0)
		{
			$new_id = $row['parent'];
			$this->getBreadCrumbs($new_id,$language);
		}
		
		$this->printMenu();
	
	}
	
	function printMenu()
	{
		$this->printBreadcums  = "";
		$count = count($this->breadcums);
		$count = $count - 1;
		for($i= $count; $i>= 0; $i--)
		{
			$this->printBreadcums .= '<span class="separator">&nbsp;&raquo;</span> <span class="link">'.ucwords($this->breadcums[$i]).'</span>';
		}
	}
	
	function menuNameExists($key, $value,$id)
	{
	
		$sql = "SELECT * FROM `{$this->table}` WHERE `{$key}` LIKE '{$value}' AND `id` <> '{$id}' ;"; //die($sql);
		//$res = mysql_query($sql)or die(mysql_error());
		
		if(mysql_fetch_assoc(mysql_query($sql)))
		{
	  		return true;
		}
		return false;
 	} 
	
	
	
#
}
?>
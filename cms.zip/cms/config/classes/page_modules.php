<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 2017 June 1
 *************************************************************************/
class page_modules extends tableObject{
	
	
	function page_modules()
	{
		$this->reset('page_modules', 'id', 'page_id,module_id');
	}
	
	function deleteItems($pid)
	{
		$query = "DELETE FROM `$this->table` WHERE `page_id` = '{$pid}' ";
		$res   = mysql_query($query)or die(mysql_error());
		return true;
	}
		
	function getContentCount($id)
	{
		$query = "SELECT * FROM `$this->table` WHERE `page_id` = '{$id}' ";
		$res   = mysql_query($query)or die(mysql_error());
		return($res);
	}
	
	function getModules($id)
	{
		$query = "SELECT * FROM `$this->table` WHERE `page_id` = '{$id}'"; 
		$res   = mysql_query($query)or die(mysql_error());
		return($res);
	}
	
}
?>
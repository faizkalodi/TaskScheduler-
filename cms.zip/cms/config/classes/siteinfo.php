<?php
/*
 * Definition for the class `siteinfo
 * @methode Definition constructor siteinfo_()
 */
class siteinfo extends tableObject{

function siteinfo(){
	$this->reset('siteinfo', 'id','title,details,upto,time');
  } 
   
   function display($id,$field)
   {
   		$query  =  "SELECT * FROM `$this->table` WHERE `id` = '{$id}'"; //die($query );
		$res    =   mysql_query($query) or die(mysql_error());
		$row 	= 	mysql_fetch_assoc($res);
		return($row[$field]);
		
   }
  
}
?>
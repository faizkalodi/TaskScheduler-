<?php
/************************************************************************
 *  Code @Faiz Kalodi
 *  Purpose: For all operations
 *  Definition for the class `user`
 *  @methode Definition constructor user()
 *  (c) All Rights Reserved 
 *  Last Updated on 2015 Aug 15
 *************************************************************************/
class user extends tableObject{

function user($loadUser = 0)
{
	$this->reset('user', 'id', 'type,fname,lname,uname,password,email,mobile,designation,department,image,newsletter,cpanel,status,refer,upto,time');
	$this->key['id'] = ($loadUser == true) ? (empty($_SESSION['UID'])? 0 : $_SESSION['UID']) : $loadUser;
	$this->select();
}
/*
 * @methode Definition isLocked()
 * Checks if a specified User in banned/locked
 */
  function isLocked($uname)
  {
	$db	 = "SELECT `id` FROM `{$this->table}` WHERE(`uname` = '{$uname}' AND `upto` <= NOW()) LIMIT 1;";
	if($db = mysql_fetch_assoc(mysql_query($db))){
	  return true;
	}
	return false;
  }
  
/*
 * @methode Definition expired()
 * Checks expired or not  
 */
 function userExpired($uname, $pass, $webmaster = false)
 {
 	global $App;
	if($webmaster)
	{
	  $db = "SELECT `upto` FROM `{$this->table}` WHERE(`uname` = '{$uname}'  AND `password` = PASSWORD('{$pass}') AND `cpanel` = '1') LIMIT 1;";
	  if($db = mysql_fetch_assoc(mysql_query($db)))
	  {
			$curdate = date('Y-m-d');
			$upto 	 = $db['upto'];
			if($curdate > $upto)
			{
				return true;
			}
	  }
	}
	else
	{
	  $db = "SELECT `upto` FROM `{$this->table}` WHERE(`uname` = '{$uname}' AND `password` = PASSWORD('{$pass}')) LIMIT 1;";//die($db);
		  if($db = mysql_fetch_assoc(mysql_query($db)))
		  {
				$curdate = date('Y-m-d');
				$upto 	 = $db['upto'];
				if($curdate > $upto)
				{
					return true;
				}
		  }
	}
 
 	
 }

function checkPass($pwd,$id)
{
	$db  = "SELECT * FROM `{$this->table}` WHERE(`password` = PASSWORD('{$pwd}') ) AND `id` = {$id};";//die($db);
	$res = mysql_query($db)or die(mysql_error());
	$nr  = mysql_num_rows($res);
	if($nr > 0)
	{
		return true;
	}
	else
	{
		return false;	
	}

}

  
/*
 * @methode Definition userblocked()
 * Checks status of user  
 */
 function userblocked($uname, $pass, $webmaster = false)
 {
 	global $App;
	if($webmaster)
	{
	  $db = "SELECT `status` FROM `{$this->table}` WHERE(`uname` = '{$uname}'  AND `password` = PASSWORD('{$pass}') AND `cpanel` = '1') LIMIT 1;";
	  if($db = mysql_fetch_assoc(mysql_query($db)))
	  {
			if($db['status'] == 2)
			{
				return true;
			}
	  }
	}
	else
	{
	  $db = "SELECT `status` FROM `{$this->table}` WHERE(`uname` = '{$uname}' AND `password` = PASSWORD('{$pass}')) LIMIT 1;";
		  if($db = mysql_fetch_assoc(mysql_query($db)))
		  {
				if($db['status'] == 2)
				{
					return true;
				}
		  }
	}
 
 	
 }


/*
 * @methode Definition getUserByEmail()
 * Getting Username from Email   
 */  
function getUserByEmail($email){
  	  $db  = "SELECT * FROM `{$this->table}` WHERE `email` = '{$email}' "; //die($db);
	  $res = mysql_query($db)or die(mysql_error());
	  while($row = mysql_fetch_array($res)){
	  	$uname = $row['uname'];
	  }
	  return $uname;
  }
  
/*
 * @methode Definition signIn()
 * For signin  
 */
  function signIn($email, $pass, $webmaster = false){
	global $App;
	

	if($webmaster){
	
	
	  $db = "SELECT `id` FROM `{$this->table}`  WHERE `uname` = '{$email}'  AND `password` = PASSWORD('$pass') AND `status` ='1' AND `cpanel` = '1'  LIMIT 1;";//die ($db);
	  if($db = mysql_fetch_assoc(mysql_query($db))){
	 	
		$this->key['id'] = $_SESSION['UID'] = $db['id'];//session_register('UID', 'CPANEL'); 
		$_SESSION['CPANEL'] = 1;
		$App->log("Signed in!");	
		return true;
	  }
	}
	/*else
	{
		
 		$db = "SELECT `id` FROM `{$this->table}`   WHERE `email` = '{$email}'  AND `password` = PASSWORD('$pass') AND `status` ='1' LIMIT 1;";//die ($db);
	 	if($db = mysql_fetch_assoc(mysql_query($db)))
		{
			$this->key['id'] = $_SESSION['UID'] = $db['id'];	//session_register('UID'); //die('test');
			//$App->log("Signed in!");
			return true;
	    }
	  
	}*/
	return false;
  }

/*
 * @methode Definition signOut()
 * For sign out  
 */
  function signOut(){
	global $App;
	$App->log("Signed Out!");
	@session_destroy();
	$this->key['id'] = $_SESSION['UID'] = '';
	unset($_SESSION['UID']);
	unset($_SESSION['CPANEL']);
	return true;

  }

/*
 * @methode Definition in()
 * Checks if a user has signed in & if have signed in on cpanel based on the param $webmaster
 */
  function in($webmaster = false){
	global $App;
	if(empty($_SESSION['UID'])){
	  return false;
	}elseif($webmaster && empty($_SESSION['CPANEL'])){
	  return false;
	}
	return true;
  }
  
/*
 * @methode Definition getRights()
 * Getting the Rigths for users
 * @global object of class application
 */
  function getRights($mod){
	global $App;
	if($this->value['id'] == 1){ 
	  return array('new' => 1, 'view' => 1, 'edit' => 1, 'delete' => 1);
	}else{
	$uid = $this->value['id']; //die ($_SESSION['UID']);
	//die ("SELECT `new`, `edit`, `delete`, IF(`view` + `edit` + `delete` > 0, 1, 0) AS `view` FROM `{$App->mySql['PREFIX']}user_rights` WHERE(`uid` = '{$uid}' AND `module` = '{$mod}' AND `upto` > NOW() AND (`new` + `view` + `edit` + `delete` > 0)) LIMIT 1;");
	$db = mysql_query("SELECT `new`, `edit`, `delete`, IF(`view` + `edit` + `delete` > 0, 1, 0) AS `view` FROM `{$App->mySql['PREFIX']}user_rights` WHERE(`uid` = '{$this->value['id']}' AND `module` = '{$mod}' AND `upto` > NOW() AND (`new` + `view` + `edit` + `delete` > 0)) LIMIT 1;");
	
	}
	
	if($db = mysql_fetch_assoc($db))
	{
	//die ('jdjjd'.$db.'hhhh');	
	  return $db;
	}
	return false;
  }
  
/*
 * @methode Definition canDo()
 * Cheking the permission for users
 * @global object of class application
 */
  function canDo($perm){
	if($this->value['id'] == 1)// > 0 && $this->value['id'] < 3)
	{
	  return true;
	}
	global $App;
	list($mod, $perm) = explode(":", $perm, 2);
	$mod = strtolower(trim($mod));
	$perm = strtolower(trim($perm));
	$db = mysql_query("SELECT `new`, `edit`, `delete`, IF(`view` + `edit` + `delete` > 0, 1, 0) AS `view` FROM `{$App->mySql['PREFIX']}user_rights` WHERE(`uid` = '{$this->value['id']}' AND `module` = '{$mod}' AND `upto` > NOW()) LIMIT 1;");
	if($db = mysql_fetch_assoc($db)){
	  if($db[$perm] > 0){
		return true;
	  }
	}
	return false;
  }
  
/*
 * @methode Definition checkType()
 * Checking the input is username / email  
 */
  function checkType($input){
	  $db = "SELECT * FROM `{$this->table}` WHERE(`uname` = '{$input}') ;";//die($db);
	  $rs = mysql_query($db) or die(mysql_error());
	  $nr = mysql_num_rows($rs);
	  if($nr > 0)
	  {
		return(1);  
	  }
	  else
	  {
	  	  $db1 = "SELECT * FROM `{$this->table}` WHERE(`email` = '{$input}') ;";//die($db1);
		  $rs1 = mysql_query($db1) or die(mysql_error());
		  $nr1 = mysql_num_rows($rs1);//die($nr1);
		  if($nr1 > 0)
		  {
			return(2);  
		  }
		  else
		  {
		  	return(3);
		  }
	  }
  
  }
  
/*
 * @methode Definition isValidUsername()
 * Validating User Name 
 */
function isValidUsername($v){
	return ereg("^[A-Z]+[a-z0-9_@.]*$", $v);
  }
  function isUsernameAvailable($v){
	$db = mysql_query("SELECT `id` FROM `{$this->table}` WHERE(`uname` = '{$v}') LIMIT 1;");
	if($db = mysql_fetch_assoc($db)){
	  return false;
	}
	return true;
  }
  
/*
 * @methode Definition changePassword()
 * Change User Password 
 */
function changePassword($cpass, $npass){
	global $App;
	$db = "UPDATE `{$this->table}` SET `password` = PASSWORD('{$npass}'), `time` = NOW() WHERE (`id` = '{$this->value['id']}' AND `password` = PASSWORD('{$cpass}')) LIMIT 1;";
	//die($db);
	mysql_query($db)or die(mysql_error());
	if(mysql_affected_rows($App->mySql['CONNECTION']) == 1){
	  $App->log("Password changed!");
	  return true;
	}
	return false;
  }
  
  
  function changePassword2($cpass, $npass,$id){
	global $App;
	$db = "UPDATE `{$this->table}` SET `password` = PASSWORD('{$npass}'), `time` = NOW() WHERE (`id` = '{$id}' AND `password` = PASSWORD('{$cpass}')) LIMIT 1;";
	//die($db);
	mysql_query($db)or die(mysql_error());
	if(mysql_affected_rows($App->mySql['CONNECTION']) == 1){
	  $App->log("Password changed!");
	  return true;
	}
	else
	{
		return false;
	}
  }
  
/*
 * @methode Definition resetPassword()
 * Reset User Password  
 */
function resetPassword($uid, $nPass){
	global $App;
	if($uid === false){
		$uid = $this->value['id'];
		$db = "UPDATE `{$this->table}` SET `password` = PASSWORD('{$nPass}'), `time` = NOW() WHERE (`id` = '{$this->value['id']}') LIMIT 1;";
	}elseif($uid > $this->value['id']){
		$db = "UPDATE `{$this->table}` SET `password` = PASSWORD('{$nPass}'), `time` = NOW() WHERE (`id` = '{$uid}') LIMIT 1;";
	}else{
		return false;
	}
	mysql_query($db) or die(mysql_error());
	if(mysql_affected_rows($App->mySql['CONNECTION']) == 1){
		@$App->log("Reset Password of {$uid}!");
		return true;
	}
	return false;
  }

/* View User Photo */
function viewUserPhoto($x =102)
{
 	 global $App;		
	 if (file_exists($App->data("users/{$this->value['photo']}", true)))
	 {
		if(!empty($this->value['photo']))
		{
			$im = getimagesize($App->data("users/{$this->value['photo']}", true));
			$title = 'Edit';//$this->value['fname'].'&nbsp;'.$this->value['lname'];
			$img = "<img src=\"".$App->data("users/{$this->value['photo']}", false)."\"   class=\"contentprofilephoto\" />";
			return $img;				
		}
		else
		{
			return '<img class="contentprofilephoto" src="Images/profile_photo.png"     />';
		}
	
	}
	else
	{
		 return '<img class="contentprofilephoto" src="Images/profile_photo.png"     />';
	}
}

/* View User Photo in left menu */
function menuProfilePic($x =102)
{

 	 global $App;		
	 if (file_exists($App->data("users/{$this->value['photo']}", true)))
	 {
		if(!empty($this->value['photo']))
		{
			$im = getimagesize($App->data("users/{$this->value['photo']}", true));
			$img = "<img src=\"".$App->data("users/{$this->value['photo']}", false)."\" class=\"contentprofilephoto\" title='Edit'  onclick=\"window.location='Ind_Profile_photo.php'\" style='cursor:pointer' />";
			return $img;				
		}
		else
		{
		return '<img class="contentprofilephoto" src="Images/profile_photo.png"  onclick="window.location=\'Ind_Profile_photo.php\'" title="Edit" style="cursor:pointer" />';
		}
	
	}
	else
	{
		 return '<img class="contentprofilephoto" src="Images/profile_photo.png" title="Edit" style="cursor:pointer" onclick="window.location=\'Ind_Profile_photo.php\'" title="Edit" style="cursor:pointer" />';
	}
}


/* View User Photo in left menu */
function menuProfilePicPP($x =102)
{
 	 global $App;		
	 if (file_exists($App->data("users/{$this->value['photo']}", true)))
	 {
		if(!empty($this->value['photo']))
		{
			$im = getimagesize($App->data("users/{$this->value['photo']}", true));
			
			$img = "<img src=\"".$App->data("users/{$this->value['photo']}", false)."\" class=\"contentprofilephoto\"  />";
			return $img;				
		}
		else
		{
		return '<img  src="Images/profile_photo.png" class="contentprofilephoto"     />';
		}
	
	}
	else
	{
		 return '<img class="contentprofilephoto" src="Images/profile_photo.png"    />';
	}
}


/* View User Photo in reviews */
function reviewProfilePic($uid)
{
	global $App;		
	$this->key['id'] = $uid;
	$this->select();
 	$x =80;
	$title = $this->value['fname'].'&nbsp;'.$this->value['lname'];

	 if (file_exists($App->data("users/{$this->value['photo']}", true)))
	 {
		if(!empty($this->value['photo']))
		{
			$im = getimagesize($App->data("users/{$this->value['photo']}", true));
			$img = "<img src=\"".$App->data("users/{$this->value['photo']}", false)."\"   class=\"contentprofilephoto\" />";

			//return $img.'ss';				
		}
		else
		{
			$img = '<img class="contentprofilephoto" src="Images/profile_photo.png"    />';
		}
	
	}
	else
	{
		$img = '<img class="contentprofilephoto" src="Images/profile_photo.png"    />';
	}
	
		$img = '<a href="ind_public2.php?id='.$this->value['id'].'" target="_blank" class="contentlinks" style="font-size: 12px;" >'.$img.'</a>';
		return $img;
}


  
/*
 * @methode Definition delete()
 * Delete User   
 */
function delete(){
	global $App;
	if($this->key['id'] > 2){
		$_t = mysql_query("DELETE FROM `{$App->mySql['PREFIX']}user_rights` WHERE (`uid` = '{$this->key['id']}');");
		//-
		$_t = mysql_query("DELETE FROM `{$this->table}` WHERE (`id` = '{$this->key['id']}') LIMIT 1;");
		if(mysql_affected_rows($App->mySql['CONNECTION']) == 1){
			$App->log("Deleting User  {$this->key['id']}!");
			return true;
		}
	}
	return false;
  }
/*
 * @methode Definition deleteAllusersbyRestaurant()
 * To delete all users under perticular restaurant
 */ 
 function deleteAllusersbyRestaurant($rid){
	$db = mysql_query("DELETE FROM `{$this->table}` WHERE `restaurant_id` = '$rid';");
	//die($db);
	return true;
  }
  
/*
 * @methode Definition userallowed()
 * User allowed for ecom
 */  

function userallowed($uid)
  {
  	$this->key['id'] = $uid;
	if($this->select())
	{
		$curdate = date('Y-m-d');
		$upto 	 = $this->value['upto'];
		
		if($curdate > $upto)
		{
			return false;
		}
		
		if($this->value['ecommerce'] == 0)
		{
			return false;
		}
		
		if($this->value['status'] == 2)
		{
			return false;
		}
		
		return true;
		
    }
  }

/*
 * @methode Definition saveThis()
 * Save profile  
 */  

function saveThis($insert=true){
	if($insert){
	  $_value = '';
	  foreach($this->value as $k => $v){
		if($k == 'time' || $k == 'password'){ continue;}
		$_value .= (($_value == '')? "`{$k}` = '{$v}'" :", `{$k}` = '{$v}'");
	  }
	  $_value .= ", `password` = PASSWORD('{$this->value['password']}')";
	  $_value .= ", `time` = NOW()";
	  //echo  $_value;
	  //die();
	  return $_value;
	}
	return parent::saveThis(false);
 }
 
/*
 * @methode Definition forgotPassword()
 * Generates a link which willbe used for resetting a user's password!
 */

function forgotPassword($email){
		global $App;
		$db = "SELECT `id`, `uname` FROM `{$this->table}` WHERE (`email` LIKE '{$email}') LIMIT 1;";
		if($db = mysql_fetch_assoc(mysql_query($db))){
			$tp = getdate();
			$tp = $tp['year'].'-'.$tp['mon'].'-'.$tp['mday'];
			$tp = "http://{$App->name}".$App->dir("user_password_forgot.php", false)."?step=2&amp;id={$db['id']}&amp;key=".urlencode(md5($tp.$db['uname']))."&amp;";
			//-
			$message  = "<p align=\"left\">Dear <b>{$db['uname']}</b>,<br /><br />";
			$message .= "You are getting this mail because you had requested for a new password at <b>{$App->name}</b>!<br>";
			$message .= "If you haven't requested for the same please ignore this mail!<br><br>";
			$message .= "You can use the following link to generate a new password.<br>";
			$message .= "Your Username is : {$db['uname']}<br>";
			$message .= "-------------------------------------------------------------<br>";
			$message .= "<a href=\"{$tp}\" target=\"_blank\">{$tp}</a><br>";
			$message .= "-------------------------------------------------------------<br>";
			$message .= "This link will be valid only on <b>{$_date}</b><br><br>";
			$message .= "Thank you, <br><br>";
			$message .= "<b>{$App->name}</b> Team!<br>";
			$message .= "</p>";
			//-
			$header[] = 'MIME-Version: 1.0';
			$header[] = "From: \"website\" <noreply@{$App->name}>";
			$header[] = "Reply-To: \"{$App->user['NAME']}\" <{$_email[0]}>";
			$header[] = "Return-Path: \"{$App->user['NAME']}\" <{$_email[0]}>";
			$header[] = 'Content-type: text/html; charset=iso-8859-1';
			$header[] = 'X-Mailer: PHP v'.phpversion();
			//-
			//die($message);
			return @mail("\"{$db['uname']}\" <{$email}>", "Your Password @ websitename!", $message, implode("\r\n", $header));
		}
		return false;
	}


/*
 * @methode Definition delImage()
 * Delete image from databse
 */ 
  
function delImage($field=false){
	global $App;
	if(!$field)
	{
	$db = "UPDATE `{$this->table}`  SET  `photo`=''  WHERE (`id` = {$this->value['id']})";
	}
	else
	{
	$db = "UPDATE `{$this->table}`  SET  `{$field}`=''  WHERE (`id` = {$this->value['id']})";
	}
		$db = mysql_query($db);
		if($db){
	  		return true;
		}else{
	  		return false;
		}
   }			
	
/*
 * @methode Definition getAge()
 * To get age from date of birth
 */ 
  	
function getAge()
{
	global $App;
	$id = $this->value['id'];
	$birthday = $this->value['dob'];
	list($year,$month,$day) = explode("-",$birthday);
	$year_diff  = date("Y") - $year;
	$month_diff = date("m") - $month;
	$day_diff   = date("d") - $day;
	if ($day_diff < 0 || $month_diff < 0)
	$year_diff--;
	return $year_diff;
}
	

/*
 * @methode Definition userActive()
 * Activate user
 */	

	function userActive()
	{
  		global $App;
		$this->getCondition();
  		$db = "UPDATE `{$this->table}` SET `status` = 1 WHERE ({$this->condition}) LIMIT 1;";
		//die ($db);
		$db = mysql_query($db);
		if(mysql_affected_rows($App->mySql['CONNECTION']) == 1){
	  		return true;
		}
		return false;
  	}

/*
 * @methode Definition userinActive()
 * De-activate user
 */		
	function userinActive()
	{
  		global $App;
		$this->getCondition();
  		$db = "UPDATE `{$this->table}` SET `status` = 0 WHERE ({$this->condition}) LIMIT 1;";
		//die ($db);
		$db = mysql_query($db);
		if(mysql_affected_rows($App->mySql['CONNECTION']) == 1){
	  		return true;
		}
		return false;
  	}

/*
 * @methode Definition getUsername()
 * Get username from id
 */	
	function getUsername($uid)
	{
  		$db 	= "SELECT `uname` FROM `{$this->table}` WHERE  `id` = {$uid} LIMIT 1";//die ($db);
		$db 	= mysql_query($db);
		$db 	= mysql_fetch_array($db);
		return 	$db[0];
  	}

/*
 * @methode Definition getname()
 * Get name from id
 */	
	function getname($uid)
	{
  		$db 	= "SELECT `uname` FROM `{$this->table}` WHERE  `id` = {$uid} LIMIT 1";//die ($db);
		$db 	= mysql_query($db);
		$db 	= mysql_fetch_array($db);
		return 	trim($db[0]);
  	}
	
	function getFullname($uid)
	{
  		$db 	= "SELECT `fname`,`lname` FROM `{$this->table}` WHERE  `id` = {$uid} LIMIT 1";//die ($db);
		$db 	= mysql_query($db);
		$db 	= mysql_fetch_array($db);
		return 	($db[0].'&nbsp;'.$db[1]);
  	}


/*
 * @methode Definition getLoggedUserName()
 * Get Full name from id
 */		
	function getLoggedUserName($uid)
	{
  		$db 	= 	"SELECT `uname` FROM `{$this->table}` WHERE  `id` = {$uid} LIMIT 1";//die ($db);
		$db 	= 	mysql_query($db)or die(mysql_error());
		$nr     =   mysql_num_rows($db);
		if($nr > 0)
		{
			
			while($row = mysql_fetch_array($db))
			{
				$name = $row['uname'];
			}
			
			return $name;
		}
  	}	
/*
 * @methode Definition getEmail()
 * Get email from id
 */	
	function getEmail($uid)
	{
  		$db 	= "SELECT `email` FROM `{$this->table}` WHERE  `id` = {$uid}";//die ($db);
		$db 	= mysql_query($db);
		$email 	= mysql_fetch_array($db);
		return $email[0];
  	}



/*
 * @methode Definition userCheck()
 * Checks user with this email
 */		
	function userCheck($uname=false,$email)
	{

	   $db	 = "SELECT  DISTINCT `id` FROM `{$this->table}` WHERE `email` = '{$email}' LIMIT 1;";
	
		if($db = mysql_fetch_assoc(mysql_query($db)))
		{
       	$id = $db['id'];	
	  	return ($id);
		}
		return false;
  	}
	
/*
 * @methode Definition cleanText()
 * Used for remove single quates and double quates(html entities) from a string
 */ 		
		function cleanText($str){
		$str = str_replace("&amp;#39;" ,"", $str);
		//$str = str_replace("&quot;" ,"", $str);
		//$str = str_replace('&#8222;' ,"", $str);
		return htmlentities($str);
		}
		
		
/*
 * @methode Definition get()
 * Get values from table
 */ 	
	function get($type)
	{
	global $App;
	$list = array();
	if($type == 'All')
	$db = "SELECT * FROM `{$this->table}` WHERE `id` > 0 ORDER BY `uname` ASC;";
	else
	$db = "SELECT * FROM `{$this->table}` WHERE `id` > 2 ORDER BY `uname` ASC;";
	$db = mysql_query($db);
	while($row = mysql_fetch_assoc($db)){
	  $list[$row['id']] = $row['uname'];
	}
	return $list;
  }
  
/*
 * @methode Definition htmlSelect()
 * Get List box items (options)
 */ 
function htmlSelect($type = false, $value = false, $any = "Admin"){
	$list = $this->get($type);

	if($value == -1)
	{
		$html = "<option value=\"-1\">[Any]</option>";
	}
	else
	{
		$html = $any ? "<option value=\"0\">{$any}</option>" : "";
	}
	
	if(is_array($value)){
	  foreach($list as $k => $v){
		$html .= isset($value[$k]) ? "<option value=\"{$k}\" selected=\"selected\">{$v}</option>" : "<option value=\"{$k}\">{$v}</option>";
	  }
	}else{
	  foreach($list as $k => $v){
		$html .= ($value == $k) ? "<option value=\"{$k}\" selected=\"selected\">{$v}</option>" : "<option value=\"{$k}\">{$v}</option>";
	  }
	}
	
	return $html;
  }
  
  /*
 * @methode Definition getByGroup()
 * Get values from table
 */ 	
	function getByGroup($selections, $removelist)
	{
		global $App;
		$list = array();
		if($selections)
		{
		 $db = "SELECT * FROM `{$this->table}` WHERE `id` > 2 AND id IN ($selections) ORDER BY `uname` ASC;";
		}
		else if($removelist)
		{
		 $db = "SELECT * FROM `{$this->table}` WHERE `id` > 2 AND id NOT IN ($removelist) ORDER BY `uname` ASC;";
		}
		else
		{
		$db = "SELECT * FROM `{$this->table}` WHERE `id` > 2 ORDER BY `uname` ASC;";
		}
		//die($db);
		$db = mysql_query($db);
		while($row = mysql_fetch_assoc($db)){
		  
		  $priority= ($row['gids']==101)? "- [High]" : "";
		  $list[$row['id']] = $row['uname']." ".$priority;
		}
		return $list;
  }
/*
	* 	@methode Definition checkmatch()
   	* 	To check if the category exists in the selected list
   	*/
  	function checkmatch($val,$selections)
  	{  	
		$cat = explode(",",$selections);
		foreach($cat as $k)
		{
			if($k == $val)
			{
				return true;
			}
		}
		return false;
  	}
  
 /*
	* 	@methode Definition htmlMultiSelect()
   	* 	To display Multiselect enabled list box
   	*/
  	function htmlMultiSelect($selections, $removelist)
  	{
		//print_r($selections);
		$list 	= 	$this->getByGroup($selections, $removelist);
		$htm 	=	'';
		foreach($list as $k => $v)
		{
			if($this->checkmatch($k,$selections))
			{
				$htm .= "<option value=\"{$k}\" selected=\"selected\">{$v}</option>";
			}
			else
			{
				$htm .= "<option value=\"{$k}\">{$v}</option>";
			}
		}
		return $htm;
  	}
  
  
  
	function strTimeOffset($toTimeZone)
	{
		if($toTimeZone == (float)$toTimeZone)	// if format = 5.5, 3.5 etc
		{
			$sign		=	'';
			if($toTimeZone < 0)
			$sign		=	'-';
			else
			if($toTimeZone > 0)
			$sign		=	'+';
			$toTZVars	=	explode('.',$toTimeZone);
			$toTimeZone	=	$sign.floor($toTZVars[0]).':'.floor($toTZVars[1] * 6);
		}
			
		if(empty($toTimeZone))
			$toTimeZone	=	'00:00';
		
		if($toTimeZone != '00:00')
		{
			$timeShift	=	substr($toTimeZone,0,1);
			$toTimeZone	=	substr($toTimeZone,1,strlen($toTimeZone));
		}
		$timeparams		=	explode(':',$toTimeZone);
		$timeHours		=	(int)$timeparams[0];		// in hours
		$timeMinutes	=	(int)$timeparams[1] / 60 ; 	// in hours
		$timeOffset		=	($timeHours + $timeMinutes) * 60 * 60; // value in seconds 
		if($timeShift	==	'-')
		$timeOffset		=	(-1)	*	$timeOffset;		
		return	$timeOffset;
	}  
  
	
	function localTime($ip,$time)
	{
	require_once("timezone/geoipcity.inc");
	require_once("timezone/geoipregionvars.php");
	require_once("timezone/timezone.php");

	$giCity = geoip_open("timezone/GeoLiteCity.dat",GEOIP_STANDARD);
 
	//$ip = '117.201.243.202';//get_ip();
	$record = geoip_record_by_addr($giCity, $ip);
 	if(!$record)
 	return false;

	$time_zone =  get_time_zone($record->country_code,$record->region);
	
	$UTC = new DateTimeZone("UTC");
	
	$newTZ = new DateTimeZone($time_zone);
	
	$time	=	strtotime($time);
	$time	=	gmdate('Y-m-d H:i:s',$time);
	
	$date = new DateTime( $time, $UTC );
	$date->setTimezone( $newTZ );
	return $date->format('D, d F Y h:i A');
	}
	
	function iptoCopuntry($ip)
	{
	require_once("timezone/geoipcity.inc");
	require_once("timezone/geoipregionvars.php");
	require_once("timezone/timezone.php");
	$giCity = geoip_open("timezone/GeoLiteCity.dat",GEOIP_STANDARD);
	$record = geoip_record_by_addr($giCity, $ip);
 	return $record->country_name;	
	}
	
	
	
	function userExists($key, $value, $utype)
	{
		if(empty($utype))
		$sql = "SELECT `{$key}` FROM `{$this->table}` WHERE(`{$key}` LIKE '{$value}') LIMIT 1;";
		else		
		$sql = "SELECT `{$key}` FROM `{$this->table}` WHERE(`{$key}` LIKE '{$value}' AND `utype` LIKE '$utype' ) LIMIT 1;";
		if(mysql_fetch_assoc(mysql_query($sql)))
		{
	  		return true;
		}
		return false;
 	} 
		
		
	# Update Data to the Database
 	function update($isPassword=false)
	{
		if($isPassword==1)
		{
		  $passEnco=$this->saveThis(true);
		}
		else
		{
		  $passEnco=$this->saveThis(false);
		}
    	global $App;
		


		//die($this->saveThis(false));
		$this->getCondition();
		$_sql = "UPDATE `{$this->table}` SET ".$passEnco." WHERE ({$this->condition}) LIMIT 1;"; //die($_sql);
		$_sql = mysql_query($_sql)or die(mysql_error());
		if(mysql_affected_rows($App->mySql['CONNECTION']) == 1)
		{
	  		$updt_id = $this->value['id'];
	  		$App->log("Updated ID:`{$updt_id}` in `{$this->table}` ");
			return true;
		}
		return false;

 	}
	
	#validate email
	function checkEmail($email) 
	{
  		if(eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email))
    	return true;
 		return false;	
	}
	
	# Check is the user have high priority
	function isHighPriority()	
	{
		if($this->value['gids']==101)
		{
			 return true;
		}
		else
		{
			return false;
		} 
	}
	
	#check if the user has a valid package
	function hasPackage()
	{
		if(!$this->in())
		return false;
		$packageExpiry	=	strtotime($this->value['package_expiry']);
		return ($packageExpiry > time())?true:false;
	}
	 
	# Update or assign package details of a user
	function updatePackage($packgeId)
	{
		$package				=	new package;		
		$package->key['id']		=	$packgeId;
		$ctime					=	date('Y-m-d H:i:s');
		
		if(!$package->select())
		return false;
		
		$packageValidity		=	$package->value['days'] * (24 * 60 * 60); // in seconds
		
		$currentPackageExpiry	=	strtotime($this->value['package_expiry']);
		$currentTime			=	strtotime($ctime);
		
		if($currentPackageExpiry < $currentTime) // No valid package exists for the user presently, Assign a new package from the time being
		{
			$newDate			=	$currentTime + $packageValidity;
		}
		else
		{		
			$newDate			=	$currentPackageExpiry + $packageValidity;
		}
		$this->value['package_expiry'] = date('Y-m-d H:i:s',$newDate);
		return ($this->update())?true:false;
	}
	
	# Prepare link to Share a folder
	function prepareShareLink($folderId)
	{
		$link	=	$this->value['id'].'#^#'.$folderId;
		$link	=	$this->idEncode($link);
		return 'shared_view.php?getfolder='.$link;
	}
	
	#decode shared folder link
	function decodeShareLink($link)
	{
		$link	=	end(explode('=',$link));
		$link	=	$this->idDecode($link);
		$link	=	explode('#^#',$link);
		$info	=	array('folderId' => $link[1], 'userId' => $link[0]);
		return $info;
	}

	#generate random alphanumeric string
	function randAlphanumeric($randomStringLength = 10)
	{
		return $this->str_rand($randomStringLength);
	}

	// Age from DOB
	function age_from_dob($dob) {

		if($dob == '0000-00-00')
		{
			return '';
		}
		else
		{
			return floor((time() - strtotime($dob)) / 31556926);
		}
		
	}

	
	function str_rand($length = 8, $seeds = 'alphanum')
	{
		// Possible seeds
		$seedings['alpha'] = 'abcdefghijklmnopqrstuvwqyz';
		$seedings['numeric'] = '0123456789';
		$seedings['alphanum'] = 'abcdefghijklmnopqrstuvwqyz0123456789';
		$seedings['hexidec'] = '0123456789abcdef';
		
		// Choose seed
		if (isset($seedings[$seeds]))
		{
			$seeds = $seedings[$seeds];
		}
		
		// Seed generator
		list($usec, $sec) = explode(' ', microtime());
		$seed = (float) $sec + ((float) $usec * 100000);
		mt_srand($seed);
		
		// Generate
		$str = '';
		$seeds_count = strlen($seeds);
		
		for ($i = 0; $length > $i; $i++)
		{
			$str .= $seeds{mt_rand(0, $seeds_count - 1)};
		}
		
		return $str;
	}

	#Get Level value from points
	function getLevel($point)
	{
		$level = 0;
		if($point  <= 0) { $level = 0; }
		if($point  >= 1     and  $point  <=   100)  { $level = 1; }
		if($point  >= 101   and  $point  <=   200)  { $level = 2; }
		if($point  >= 201   and  $point  <=   300)  { $level = 3; }
		if($point  >= 301   and  $point  <=   400)  { $level = 4; }
		if($point  >= 401   and  $point  <=   500)  { $level = 5; }
		if($point  >= 501   and  $point  <=   600)  { $level = 6; }
		if($point  >= 601   and  $point  <=   700)  { $level = 7; }
		if($point  >= 701   and  $point  <=   800)  { $level = 8; }
		if($point  >= 801   and  $point  <=   900)  { $level = 8; }
		if($point  >= 901   and  $point  <=   1000) { $level = 10; }
		return $level;
	}
	

	#
	function isRefUserExist($uid)
	{
		$db = "SELECT * FROM `$this->table` WHERE `id` = {$uid} AND `status` = 1";//die($db);
		$rs = mysql_query($db)or die(mysql_error());
		if(mysql_num_rows($rs) >0)
		{
			return true;
		}
	}

	#Get the users registered by referral of the given user id
	function getMyReferUsers($id)
	{
		$db = "SELECT * FROM `$this->table` WHERE `refid` = {$id} AND `status` = 1";//die($db);
		$rs = mysql_query($db)or die(mysql_error());
		if(mysql_num_rows($rs) >0)
		{
			return ($rs);
		}
		else
		{
			return false;
		}
	}

	function getRandomUser()
	{
		$db = "SELECT * FROM `$this->table` WHERE  `email_confirm` = '1' and  `status`= '1' and  `gids`='133'  ORDER BY RAND() LIMIT 1";//die($db);
		$rs = mysql_query($db)or die(mysql_error());
		return($rs);
			
	}
	
	function getEmployeelist()
	{
		$db = "SELECT * FROM `$this->table` WHERE  `type` = '102' and  `status`= '1' ORDER BY `fname` ASC ";//die($db);
		$rs = mysql_query($db)or die(mysql_error());
		return($rs);
			
	}
 #- End Class
 }
?>
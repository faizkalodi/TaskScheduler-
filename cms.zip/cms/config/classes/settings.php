<?php 
/**
 * Definition for the setting class
 * @methode Definition constructor  setting() 
 */
class settings extends tableObject{
	function settings(){
		$this->reset("settings", "id", "value,desc,input_type,time");
	}
	
	function showGFSettings($id_cond = false) // Select All rows in settings
	{
		$db	 	 	 = 	"SELECT * FROM `{$this->table}` WHERE 1 ";
		$db	 		.= 	empty($id_cond)?"": " AND `id` > {$id_cond} " ;
		$db	 		.= 	"ORDER BY `order`"; //die($db);
		$query	 	 = 	mysql_query($db);
		$result	 	 =	array();
		while($row	 =	mysql_fetch_assoc($query))
		$result[]	 =	$row;	
		return $result;
	}
	
	function showSettings($id_cond = false) // Select All rows in settings
	{
		$db	 	 	 = 	"SELECT * FROM `{$this->table}` WHERE 1 ";
		$db	 		.= 	empty($id_cond)?"": " AND `id` < {$id_cond} " ;
		$db	 		.= 	"ORDER BY `order`"; //die($db);
		$query	 	 = 	mysql_query($db);
		$result	 	 =	array();
		while($row	 =	mysql_fetch_assoc($query))
		$result[]	 =	$row;	
		return $result;
	}
	
	function getVal($id) // Allowed time between two views, for earnings calculation, in seconds
	{
		if(!is_numeric($id) or $id <= 0 )
		return false;
		$db	 	= 	"SELECT value FROM `{$this->table}` WHERE `id` = $id limit 1";
		$query	= 	mysql_query($db);
		if(!$query)		
		return false;
		$row	=	mysql_fetch_assoc($query);
		return	$row['value'];
	}

	// getting the value from setting s table
	function getValue($id)
	{
		$db	 	= 	"SELECT value FROM `{$this->table}` WHERE `id` = $id limit 1";
		$query	= 	mysql_query($db)or die(mysql_error());
		if(!$query)
		{
			return false;
		}
		else
		{
			$row = mysql_fetch_assoc($query);
			return $row['value'];
		}

	}


}	
?>
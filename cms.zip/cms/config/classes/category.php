<?php 
 /*
  * Definition  the `category` class
  * @methode Definition constructor category() for database activity 
  */
class category extends tableObject
{
	function category()
  	{
		$this->reset("category", "id", "parent,value,time");
  	}
 	
	/*
 	* 	@methode Definition getID()
  	* 	Get Category List as Array by Group Name (and Parent ID)
  	*/
  	function getID($name, $parentID = 1)
  	{
		global $App;
		$db 	= 	"SELECT `id` FROM `{$this->table}` WHERE(`parent` = '{$parentID}' AND `value` LIKE '{$name}') LIMIT 1;";
		$db 	= 	mysql_query($db);
		if($db 	= 	mysql_fetch_assoc($db))
		{
	  		return $db['id'];
		}
		return false;
  	}

 	/*
	* 	@methode Definition get()
  	* 	Get Category List as Array by Group ID(Parent)
  	*/	
	function get($groupID,$selectedIDs = '')
	{
		global $App;
		$list 	= 	array();
		if(empty($selectedIDs))
		{
			$db 	= 	"SELECT * FROM `{$this->table}` WHERE (`parent` = '{$groupID}') ORDER BY `time` ASC;";
		}
		else
		{
			$db 	= 	"SELECT * FROM `{$this->table}` WHERE `id` IN ($selectedIDs) ORDER BY FIND_IN_SET(`id`, '$selectedIDs') ";
		}
		$db 		= 	mysql_query($db);


		while($row = mysql_fetch_assoc($db))
		{
			$list[$row['id']] = $row['value'];
		}
		return $list;
  	}


	function getCatByVal($groupID,$selectedIDs = '')
	{
		global $App;
		$list 	= 	array();
		if(empty($selectedIDs))
		$db 	= 	"SELECT * FROM `{$this->table}` WHERE (`parent` = '{$groupID}') ORDER BY `value` ASC;";
		else
		{
		$db 	= 	"SELECT * FROM `{$this->table}` WHERE `id` IN ($selectedIDs) ORDER BY FIND_IN_SET(`id`, '$selectedIDs') ";
		}
		$db 	= 	mysql_query($db);
		while($row = mysql_fetch_assoc($db))
		{
			$list[$row['id']] = $row['value'];
		}
		return $list;
  	}

	/*
	* 	@methode Definition get()
  	* 	Get Category List by removing thee given value as Array by Group ID(Parent)
  	*/	
	function getByRem($groupID,$remId)
	{
		global $App;
		$list 	= 	array();
		$db 	= 	"SELECT * FROM `{$this->table}` WHERE (`parent` = '{$groupID}') AND `id` <> '{$remId}'  ORDER BY `time` ASC;";
		$db 	= 	mysql_query($db);
		while($row = mysql_fetch_assoc($db))
		{
			$list[$row['id']] = $row['value'];
		}
		return $list;
  	}
	
	/*
	* 	@methode Definition get()
  	* 	Get Category List as Array by Group ID(Parent)
  	*/	
	function getAsArray($selectedIDs = false,$inList = false)
	{
		global $App;
		$list 	= 	array();
		if(!$inList)
		$db 	= 	"SELECT * FROM `{$this->table}` WHERE 1 ORDER BY `time` ASC;";
		else
		{
		if(empty($selectedIDs))
		$selectedIDs	=	0;
		$db 	= 	"SELECT * FROM `{$this->table}` WHERE `id` IN ($selectedIDs)";
		}
		$db		=	mysql_query($db);
		while($row = mysql_fetch_assoc($db))
		{
			$list[$row['id']] = $row['value'];
		}
		return $list;
  	}
	
	/*
	* 	@methode Definition getCategories()
  	* 	Get Category List as Record Set
  	*/ 
	function getCategories($groupID)
	{
		global 	$App;
		$list 	= 	array();
		$db 	= 	"SELECT * FROM `{$this->table}` WHERE (`parent` = '{$groupID}') ORDER BY `time` DESC;";
		$db 	= 	mysql_query($db);
		return $db;
	}
	
	function getCategories2($groupID)
	{
		global 	$App;
		$list 	= 	array();
		$db 	= 	"SELECT * FROM `{$this->table}` WHERE (`parent` = '{$groupID}') ORDER BY `value` ASC;";
		$db 	= 	mysql_query($db);
		return $db;
	}
	

	function getCategoriesByOrder($groupID)
	{
		global 	$App;
		$list 	= 	array();
		$db 	= 	"SELECT * FROM `{$this->table}` WHERE (`parent` = '{$groupID}') ORDER BY `time` DESC;";
		$db 	= 	mysql_query($db);
		return $db;
	}
	

	function getCategoryArray($groupID)
	{
		global 	$App;
		$list 	= 	array();
		$db 	= 	"SELECT * FROM `{$this->table}` WHERE (`parent` = '{$groupID}') ORDER BY `id` ASC;";
		$db 	= 	mysql_query($db);
		while($row	=	mysql_fetch_assoc($db))
		{
			$list[$row[id]]	=	$row[value];
		}
		return $list;
	}
	/*
	* 	@methode Definition isValidCategory()
  	* 	Tocheck the category is valid by checking with parent id
  	*/ 
	function isValidCategory($cid,$pid)
	{
	 $db 	= 	"SELECT `parent` FROM `{$this->table}` WHERE `id` = '{$cid}'";
	 $db 	= 	mysql_query($db);
	 $row=mysql_fetch_array($db);
	 if($row['parent']==$pid)
	 {
	 	return true;
	 }
	 else
	 {
	    return false;
	 }
	}
		
	function getJSArray($groupID)
	{
		global 	$App;
		$str	=	'';
$str	.=	"countryId	=	new Array();\ncountryNm	=	new Array();\nstateId	=	new Array();\nstateNm	=	new Array();\nplaceId	=	new Array();\nplaceNm	=	new Array();\ncityId	=	new Array();\ncityNm	=	new Array();\n";
		
		$countries		=	$this->getCategoryArray($groupID);	
		$cnt_i			=	0;
		foreach($countries	as $C_id => $C_name)
		{
		
			$str		.=	"countryId[$cnt_i]	=	$C_id;\n";
			$str		.=	"countryNm[$cnt_i]	=	'$C_name';\n";
			
			$states		=	array();
			$states		=	$this->getCategoryArray($C_id);	
			
$str		.=	"stateId[$cnt_i]	=	new Array();\nstateNm[$cnt_i]	=	new Array();\nplaceId[$cnt_i]	=	new Array();\nplaceNm[$cnt_i]	=	new Array();\ncityId[$cnt_i]	=	new Array();\ncityNm[$cnt_i]	=	new Array();\n";	
			
			$st_i=0;		
			foreach($states	as $S_id => $S_name)
			{			
				$str		.=	"stateId[$cnt_i][$st_i]	=	$S_id;\n";
				$str		.=	"stateNm[$cnt_i][$st_i]	=	'$S_name';\n";
				
					
				$str		.=	"placeId[$cnt_i][$st_i]	=	new Array();\nplaceNm[$cnt_i][$st_i]	=	new Array();\ncityId[$cnt_i][$st_i]	=	new Array();\ncityNm[$cnt_i][$st_i]	=	new Array();\n";	
				
				$dists		=	array();
				$dists		=	$this->getCategoryArray($S_id);
				$dist_i=0;		
				foreach($dists	as $D_id => $D_name)
				{
					$str		.=	"placeId[$cnt_i][$st_i][$dist_i]	=	$D_id;\n";
					$str		.=	"placeNm[$cnt_i][$st_i][$dist_i]	=	'$D_name';\n";
					$str		.=	"cityId[$cnt_i][$st_i][$dist_i]	=	new Array();\n";
					$str		.=	"cityNm[$cnt_i][$st_i][$dist_i]	=	new Array();\n";
					
					$cities		=	array();
					$cities		=	$this->getCategoryArray($D_id);
					$city_i=0;
					foreach($cities	as $city_id => $city_name)
					{
					$str		.=	"cityId[$cnt_i][$st_i][$dist_i][$city_i]	=	$city_id;\n";
					$str		.=	"cityNm[$cnt_i][$st_i][$dist_i][$city_i]	=	'$city_name';\n";						
					
					$city_i++;
					}
					$dist_i++;
				}
				$st_i++	;		
			}		
		$cnt_i++;
		}
		return $str;
	}

 	/*
	* 	@methode Definition getValue()
   	* 	Get a category value
   	*/
  	function getValue($id, $error = false)
	{
		global $App;
		$db 	= 	"SELECT * FROM `{$this->table}` WHERE (`id` = '{$id}') LIMIT 1;";
		$db 	= 	mysql_query($db);
		if($db 	= 	mysql_fetch_assoc($db))
		{
	  		return $db['value'];
		}
		return $error;
  	}
  
  	/*
	* 	@methode Definition htmlSelect()
   	* 	Wrap the category to an HTML select tag
   	*/
  	function htmlSelect($list, $value = false, $any = "Select")
	{
		$list = $this->get($list);
		if($value == -1)
		{
			$html = "<option value=\"-1\">[Any]</option>";
		}
		else
		{
			$html = $any ? "<option value=\"\">{$any}</option>" : "";
		}
	
		if(is_array($value))
		{
	  		foreach($list as $k => $v)
			{
				$html .= isset($value[$k]) ? "<option value=\"{$k}\" selected=\"selected\">{$v}</option>" : "<option value=\"{$k}\">{$v}</option>";
	  		}
		}
		else
		{
	  		foreach($list as $k => $v)
			{
			$html .= ($value == $k) ? "<option value=\"{$k}\" selected=\"selected\">{$v}</option>" : "<option value=\"{$k}\">{$v}</option>";
	  		}
		}
		return $html;
  	}
#
function htmlSelectVal($list, $value = false, $any = "Select")
	{
		$list = $this->getCatByVal($list);
		if($value == -1)
		{
			$html = "<option value=\"-1\">[Any]</option>";
		}
		else
		{
			$html = $any ? "<option value=\"\">{$any}</option>" : "";
		}
	
		if(is_array($value))
		{
	  		foreach($list as $k => $v)
			{
				$html .= isset($value[$k]) ? "<option value=\"{$v}\" selected=\"selected\">{$v}</option>" : "<option value=\"{$v}\">{$v}</option>";
	  		}
		}
		else
		{
	  		foreach($list as $k => $v)
			{
			$html .= ($value == $k) ? "<option value=\"{$v}\" selected=\"selected\">{$v}</option>" : "<option value=\"{$v}\">{$v}</option>";
	  		}
		}
		return $html;
  	}



  	
  	/*
	* 	@methode Definition checkmatch()
   	* 	To check if the category exists in the selected list
   	*/
  	function checkmatch($val,$selections)
  	{  	
		$cat = explode(",",$selections);
		foreach($cat as $k)
		{
			if($k == $val)
			{
				return true;
			}
		}
		return false;
  	}
  
  	/*
	* 	@methode Definition htmlMultiSelect()
   	* 	To display Multiselect enabled list box
   	*/
  	function htmlMultiSelect($list, $selections)
  	{
		$list 	= 	$this->get($list);
		$htm 	=	'';
		foreach($list as $k => $v)
		{
			if($this->checkmatch($k,$selections))
			{
				$htm .= "<option value=\"{$k}\" selected=\"selected\">{$v}</option>";
			}
			else
			{
				$htm .= "<option value=\"{$k}\">{$v}</option>";
			}
		}
		return $htm;
  	}
 
 	/*
	* 	@methode Definition exists()
   	* 	Check if duplicate exists
   	*/
  	function exists($parentID, $value)
	{
		$db 	= 	"SELECT * FROM `{$this->table}` WHERE (`parent` = '{$parentID}' AND `value` LIKE '{$value}');";
		$db 	= 	mysql_query($db)or die(mysql_error());
		if($db 	= 	mysql_fetch_assoc($db))
		{
	  		return true;
		}
		return false;
  	}
  
  	/*
	* 	@methode Definition add()
   	* 	Add Value to database
   	*/
  	function add($parentID, $value)
	{
		//die($db);
		if($parentID > 1)
		{
	  		$this	->	value['id'] = $this->nextID();
	  		$this	->	value['parent'] = $parentID;
	  		$this	->	value['value'] = $value;
	  		if($this->	insert())
			{
				return $this->value['id'];
	  		}
		}
		return false;
  }
 
 	/*
	* 	@methode Definition remove()
   	* 	Remove an entire Node
   	*/
  	function remove($id)
	{
		global $App;
		if($id <= 100) 
			return false;
		$db1 		= 	"SELECT * FROM `{$this->table}` WHERE (`parent` = '{$id}');";
		$db1 		= 	mysql_query($db1);
		while($row 	= 	mysql_fetch_assoc($db1))
		{
	  		$this->remove($row['id']);
		}
		//-
		$db2 		= 	"DELETE FROM `{$this->table}` WHERE (`id` = '{$id}') LIMIT 1;";
		$db2 		=	mysql_query($db2);
		if(mysql_affected_rows($App->mySql['CONNECTION']) == 1)
		{
	  		return true;
		}
		return false;
  	}
  
  	/*
	* 	@methode Definition catList()
   	* 	List category as html
   	*/
  	function catList($list, $value = false, $any = "")
	{
		$list 	= 	$this->get($list);
		$html 	= 	'';
		if(is_array($value))
		{
	  		foreach($list as $k => $v)
			{
				$html .= isset($value[$k]) ? "<div align='left'><img src='images/menu.gif' border='0' />&nbsp;&nbsp;<a href='vitjana_content.php?cat={$k}' class='violet_mal'><font class=\"mal_font\">{$v}</font></a></div>" : "<div align='left'><img src='images/menu.gif' border='0' />&nbsp;&nbsp;<a href='vitjana_content.php?cat={$k}' class='violet_mal'><font class=\"mal_font\">{$v}</font></a></div>";
	  		}
		}
		else
		{
	  		foreach($list as $k => $v)
			{
				$html .= ($value == $k) ? "<div align='left'><img src='images/menu.gif' border='0' />&nbsp;&nbsp;<a href='vitjana_content.php?cat={$k}' class='violet_mal'><font class=\"mal_font\">{$v}</font></a></div>" : "<div align='left'><img src='images/menu.gif' border='0' />&nbsp;&nbsp;<a href='vitjana_content.php?cat={$k}' class='violet_mal'><font class=\"mal_font\">{$v}</font></a></div>";
	  		}
		}
		return $html;
  	}
  
  	/*
	* 	@methode Definition select_sub()
   	* 	Select Sub Category
   	*/
  	function select_sub($list, $value = false)
	{ 
		//die ($list);
		$cat 	= 	$list;	
		$list 	= 	$this->get($list);
		$html 	= 	'';
		$ctc 	= 	0;
		if(is_array($value))
		{
	  		foreach($list as $k => $v)
			{
	  			$ctc = $ctc + 1;
	  			$html .= isset($value[$k]) ? "<td style=\"padding-left:20px; padding-top:10px\" class=\"\"><img src='images/menu_2.gif' border='0' />&nbsp;&nbsp;<a href=\"vitjana_details.php?cat={$cat}&sub={$k}\" class=\"btmlink\"><font class=\"mal_font\" size=\"2\">{$v}</font></a></td>" : "<td style=\"padding-left:20px; padding-top:10px\" class=\"\"><img src='images/menu_2.gif' border='0' />&nbsp;&nbsp;<a href=\"vitjana_details.php?cat={$cat}&sub={$k}\" class=\"btmlink\"><font class=\"mal_font\" size=\"2\">{$v}</font></a></td>";
	  			if($ctc%3 == 0)
					$html .= "<tr></tr>";
		
	  		}
		}
		else
		{
	  		foreach($list as $k => $v)
			{
				$html .= ($value == $k) ? "<td style=\"padding-left:20px; padding-top:10px\" class=\"\"><img src='images/menu_2.gif' border='0' />&nbsp;&nbsp;<a href=\"vitjana_details.php?cat={$cat}&sub={$k}\" class=\"btmlink\"><font class=\"mal_font\" size=\"2\">{$v}</font></a></td>" : "<td style=\"padding-left:20px; padding-top:10px\" class=\"\"><img src='images/menu_2.gif' border='0' />&nbsp;&nbsp;<a href=\"vitjana_details.php?cat={$cat}&sub={$k}\" class=\"btmlink\"><font class=\"mal_font\" size=\"2\">{$v}</font></a></td>";
	  			$ctc = $ctc + 1;
				if($ctc%3 == 0)
					$html .= "<tr></tr>";
	  		}
		}
		return $html;
  	}
	
	
	
	
}?>
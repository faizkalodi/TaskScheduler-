<?php
/* ************************************************************************
 *  Code @Faiz Kalodi
 *  Project: Task Scheduler
 *  Purpose : Configuration file application.php 
 *  (c) All Rights Reserved
 *  Last Updated on 10 April 2020
 **************************************************************************/
define('DOCUMENT_ROOT', rtrim($_SERVER['DOCUMENT_ROOT'], "/"), true);
define('NONE', false, true);
/*
 * Definition for the Application class
 */
class application{
  var $classes 		= 	array(),
      $cpanel 		= 	false,
	  $user 		= 	array(),
	  $dir 			= 	false,
	  $name 		= 	false,
	  $mySql 		= 	array(),
	  $message 		=	false,
	  $language		=	false,
	  $logo			=	false,
	  $adminlogo	=	false,
	  $email_sign 	= 	false,
	  $site_title	=   false;
	  

  function application(){
  #- Initialize DIR
    $this->dir = DOCUMENT_ROOT."/";
  #- Initialize Project Name
    $this->name = false;
  #- Initialize MySQL
	$this->mySql['CONNECTION'] = false;
	$this->mySql['SERVER'] = false;
	$this->mySql['USER'] = false;
	$this->mySql['PASSWORD'] = false;
	$this->mySql['DATABASE'] = false;
	$this->mySql['PREFIX'] = false;
  #- Initialize User
	$this->wm['UID'] = false;
	$this->wm['NAME'] = false;
	$this->wm['EMAIL'] = false;

	

  }

  function lock($_lockBY, $_lockFor)
  {
		$this->incFile("classes/tableObject.php");
		$this->incFile("classes/user.php");
		$user = new user(true);
		if($_lockBY)
		{
			if($this->cpanel)
			{
				if(empty($_SESSION['UID']))
				{
					header("location:../../index.php?error_msg=auth");die();
				}
				else if($user->value['cpanel']!= 1)
				{
					header("location:../../index.php?error_msg=auth");die();
				}
			}
			else
			{
				if(empty($_SESSION['UID']))
				{
					echo 'You are not authorised for this action<br> Please Login';die();
				}
			}
			#end ifelse
		}#end lock
  }

  #- Terminate the Action with a smooth message, with out losing the GUI
  function message($_Text, $heading, $title = false, $href = false, $a_text = false,$menu = false){
	$href = $href ? $href : "javascript:window.history.back();";
	$a_text = $a_text ? $a_text : "Back";
	//-
	define('TEXT', $_Text, true);
	define('HEADING', $heading, true);
	define('TITLE', $title ? $title : $heading, true);
	define('HREF', (strtolower(substr($href, 0, 11)) == "javascript:") ? $href : $this->dir($href, false), true);
	define('BUTTON_TEXT', $a_text, true);
	define('MENU', $menu, true);
	require_once($this->dir($this->cpanel ? "admin/message.php" : "message.php"));
	exit;
  }
  
  function message2($_Text, $heading, $title = false, $href = false, $a_text = false,$menu = false){
	$href = $href ? $href : "javascript:window.history.back();";
	$a_text = $a_text ? $a_text : "Back";
	//-
	define('TEXT', $_Text, true);
	define('HEADING', $heading, true);
	define('TITLE', $title ? $title : $heading, true);
	define('HREF', (strtolower(substr($href, 0, 11)) == "javascript:") ? $href : $this->dir($href, false), true);
	define('BUTTON_TEXT', $a_text, true);
	define('MENU', $menu, true);
	require_once($this->dir($this->cpanel ? "admin/message.php" : "message.php"));
	exit;
  }

  function setup($_cpanel = true, $_classes = false, $_lockBY = false, $_lockFor = NONE){
    global $_SESSION;

	
  #- Setup CPanel Mode
	if($_cpanel){ $this->cpanel = "admin/";}
  #- Include the class File[s]
	if($_classes){
	  $this->incFile("classes/tableObject.php");
	  $this->classes = explode(",", $_classes);
	  foreach($this->classes as $k => $v){
	    $v = trim($v, " \n\t");
		if(file_exists($this->dir("config/plugins/{$v}/{$v}.php", true))){
		  $this->incFile("plugins/{$v}/{$v}.php");
		}else{
		  $this->incFile("classes/{$this->classes[$k]}.php");
		}
	  }
	}
  #- Connect to MySQL and select a database Database
	if($this->mySql['SERVER']){ $this->mySql['CONNECTION'] = mysql_connect($this->mySql['SERVER'], $this->mySql['USER'], $this->mySql['PASSWORD']) or die("DB Error!");}
	if($this->mySql['CONNECTION'] && $this->mySql['DATABASE']){ mysql_select_db($this->mySql['DATABASE'], $this->mySql['CONNECTION']);}
  #- Start Session / Send Header[s]
    @session_start();
  #- Lock the Page according to user's permissions
	if($_lockBY){ $_setup = $this->lock($_lockBY, $_lockFor);}
  #- Load the Name / Email of Current Administrator
	$_tp = mysql_query("SELECT `uname`, `email` FROM `{$this->mySql['PREFIX']}user` WHERE (`id` = '{$this->wm[UID]}') LIMIT 1;") or die(mysql_error());
	if($_tp = mysql_fetch_assoc($_tp)){
	  $this->wm['NAME'] = $_tp['uname'];
	  $this->wm['EMAIL'] = $_tp['email'];
	}
  #- Return TRUE for this Method
	return true;
  }
  
  function incFile($_path, $_force = false){
  #- Include any file[s] in the config directory using require functions
    $_tp = $this->dir."config/";
	if($_force){
      require($_tp.$_path);
	}else{
      require_once($_tp.$_path);
	}
	return true;
  }
  
  function dir($_url = "", $_server = true){
  #- Return any path, relative to the Site root, either for PHP or browser use
	$_tmp = str_replace("\\", "/", realpath($this->dir.$_url));
	if(!$_server){
	  $_tmp = str_replace(DOCUMENT_ROOT, "", $_tmp);
	}
	return $_tmp;
  }
  //editor_selector : \"wysiwyg_adv\"
  function tiny_fck($val)
  {
  	if($val =='false')
	{
	$a = '<script language="javascript" type="text/javascript" src="config/plugins/tinyfck/tiny_mce.js"></script>';
	}
	else if($val =='true')
	{
			$a = '<script language="javascript" type="text/javascript" src="../../../config/plugins/tinyfck/tiny_mce.js"></script>';
		
	}
$a .= '<script language="javascript" type="text/javascript">
	tinyMCE.init({
		mode : "textareas",
		theme : "advanced",
		editor_selector :"wysiwyg_adv",
		plugins : "table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,zoom,flash,searchreplace,print,paste,directionality,fullscreen,noneditable,contextmenu",
		theme_advanced_buttons1_add_before : "save,newdocument,separator",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,insertdate,inserttime,preview,zoom,separator,forecolor,backcolor,liststyle",
		theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "emotions,iespell,flash,advhr,separator,print,separator,ltr,rtl,separator,fullscreen",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		plugin_insertdate_dateFormat : "%Y-%m-%d",
		plugin_insertdate_timeFormat : "%H:%M:%S",
		extended_valid_elements : "hr[class|width|size|noshade]",
		file_browser_callback : "fileBrowserCallBack",
		paste_use_dialog : false,
		theme_advanced_resizing : true,
		theme_advanced_resize_horizontal : false,
		theme_advanced_link_targets : "_something=My somthing;_something2=My somthing2;_something3=My somthing3;",
		apply_source_formatting : true
	});

	function fileBrowserCallBack(field_name, url, type, win) {
		var connector = "../../filemanager/browser.html?Connector=connectors/php/connector.php";
		var enableAutoTypeSelection = true;

		var cType;
		tinyfck_field = field_name;
		tinyfck = win;

		switch (type) {
			case "image":
				cType = "Image";
				break;
			case "flash":
				cType = "Flash";
				break;
			case "file":
				cType = "File";
				break;
		}

		if (enableAutoTypeSelection && cType) {
			connector += "&Type=" + cType;
		}

		window.open(connector, "tinyfck", "modal,width=600,height=400");
	}
</script>';
echo $a;
  }

function metaKeywords()
  {
  	$this->incFile("classes/tableObject.php");
	$this->incFile("classes/settings.php");
    $settings = new settings(true);
	$keyword = $settings->getVal(13);
	$metakw="<meta name=\"keywords\" content=\"{$keyword}\" /> ";
	$desc = $settings->getVal(16);
	$metade = "<meta name=\"description\" content=\"{$desc}\" />"; 
	$metalan= "<meta http-equiv=\"content-language\" content=\"en\">";
	$meta=$metakw.$metade.$metalan;
	return $meta;
  }
  
function welcomeLogedUser()
  {
  	$this->incFile("classes/tableObject.php");
	$this->incFile("classes/user.php");
    $weluser = new user(true);
	$welusername = $weluser->getLoggedUserName($_SESSION['UID']);
	return $welusername;
  }
    
  function data($_url, $_server = true){
  #- Return any path in the data directory, relative to the Site root, either for PHP or browser use
	$_tmp = $this->dir;
	$_tmp .= "config/data/{$_url}";
	$_tmp = str_replace("\\", "/", realpath($_tmp));
	if(!$_server){
	  $_tmp = str_replace(DOCUMENT_ROOT, "", $_tmp);
	}
	//die($this->name);
	return $_tmp;
  }
  
  
    function menu($_url, $_server = true){
  #- Return any path in the data directory, relative to the Site root, either for PHP or browser use
	$_tmp = $this->dir;
	$_tmp .= "admin/{$_url}";
	
	$_tmp = str_replace("\\", "/", realpath($_tmp));
	if(!$_server){
	  $_tmp = str_replace(DOCUMENT_ROOT, "", $_tmp);
	}
	//die($this->name);
	return $_tmp;
	
  }
 
	function getIp()
	{
		if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
		{
			$ip	=	$_SERVER['HTTP_CLIENT_IP'];
		}
		elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
		{
			$ip	=	$_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else
		{
			$ip	=	$_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}
  
	function log($msg)
	{
		if($this->cpanel)
		{
	  		$msg 	= "Admin: {$msg}";
		}
		$ip			=	$this->getIp();
		$id			=	(int)$_SESSION['UID'];
		$time		=	date('Y-m-d H:i:s');
		if($id)
		{
			$db = "INSERT INTO `{$this->mySql['PREFIX']}user_logs`(`uid`,`ip`, `time`, `notes`) VALUES('{$id}','{$ip}', '{$time}', '{$msg}');";
			$db = mysql_query($db);
		}
		return true;
 	}
# function to check the security code set..
	function checkSecCode()
	{
		if(isset($_SESSION['sec_code']) && $_SESSION['sec_code'] != '')
		{
			//die ('kjk');
		}
		else
		{
			$this->message('Sorry the security code is not set', 'Access Denied', false, 'ecom_sec_code.php', 'Set Code');
		}
	}
  
};

$App = new application();
#-System Settings
$App->site_title		= "CMS";
$App->name 				= 'http://localhost/cms';
$App->logo 				= 'http://localhost/cms/img/logo.png';
$App->adminlogo 		= 'http://localhost/cms/admin/dist/logo/logo.png';
$App->mySql['PREFIX'] 	= 'xx_';
$App->mySql['SERVER'] 	= 'localhost';
$App->mySql['USER'] 	= 'root';
$App->mySql['PASSWORD'] = '';
$App->mySql['DATABASE'] = 'cms';
$tp = str_replace("\\", "/", dirname(dirname(__FILE__)));
$App->dir .= basename($tp)."/";
#*/

?>